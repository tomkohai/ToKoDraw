import bpy

class td_PT_utilities(bpy.types.Panel):
    bl_label = "Utilities"
    bl_idname = "td_PT_utilities"
    bl_parent_id = "td_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "ToKoDraw"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(setd, context):
        layout = setd.layout
        layout.label(text="Tools & Maintenance")
        layout.operator("td.reset_popups", icon="FILE_REFRESH")
