import bpy
from ..core.layer_utils import (
    get_active_layer_tex_node,
    get_active_layer_group,
)

from ..core.layer_chain_utils import get_layer_chain



class td_PT_Animate(bpy.types.Panel):
    bl_label = "ToKoDraw Animate"
    bl_idname = "td_PT_ANIMATE"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "ToKoDraw"
    bl_options = {'DEFAULT_CLOSED'}


    def draw(setd, context):
        layout = setd.layout
        scene = context.scene

        box = layout.box()




        row = box.row(align=True)   
 

        active_layer = get_active_layer_group(context)

        if active_layer:
            ui_name = active_layer.get("td_ui_name", active_layer.label)
            row.label(text=f"Layer: {ui_name}")
        else:
            row.label(text="Layer: None")
            return



        row.operator("td.layer_up", text="", icon="TRIA_UP")
        row.operator("td.layer_down", text="", icon="TRIA_DOWN")




        row = layout.row(align=True)
        row.label(text="Animate Layer")
        row.prop(context.scene, "td_animate_layer", text="")





        row = layout.row(align=True)

        mat = context.object.active_material


        tex_node = next(
            (n for n in active_layer.node_tree.nodes if n.type == 'TEX_IMAGE'),
            None
        )
        icon = "HIDE_OFF" if (tex_node and not tex_node.mute) else "HIDE_ON"
        op = row.operator("td.toggle_layer_visibility", text="", icon=icon)
        op.layer_name = active_layer.node_tree.name


        layers = get_layer_chain(mat)

        def is_layer_solo(layer):
            tex_current = next(
                (n for n in layer.node_tree.nodes if n.type == 'TEX_IMAGE'),
                None
            )
            if not tex_current or tex_current.mute:
                return False

            for other in layers:
                if other == layer:
                    continue

                tex_other = next(
                    (n for n in other.node_tree.nodes if n.type == 'TEX_IMAGE'),
                    None
                )

                if tex_other and not tex_other.mute:
                    return False
            return True

        icon = "SOLO_ON" if is_layer_solo(active_layer) else "SOLO_OFF"
        op = row.operator("td.toggle_layer_solo", text="", icon=icon)
        op.layer_name = active_layer.node_tree.name


        lock_alpha = active_layer.node_tree.get("td_lock_alpha", False)
        icon = "LOCKED" if lock_alpha else "UNLOCKED"
        op = row.operator("td.toggle_lock_alpha", text="", icon=icon)
        op.layer_name = active_layer.node_tree.name


        lock_layer = active_layer.node_tree.get("td_lock_layer", False)
        icon = "LOCKVIEW_ON" if lock_layer else "LOCKVIEW_OFF"
        op = row.operator("td.toggle_lock_layer", text="", icon=icon)
        op.layer_name = active_layer.node_tree.name


        op = row.operator("td.rename_layer", text="", icon="GREASEPENCIL")
        op.layer_name = active_layer.get("td_uid")

     



        settings_key = f"{active_layer.node_tree.name}_animate_open"
        settings_open = bool(scene.get(settings_key, False))

        row = layout.row(align=True)
        arrow = row.operator("td.open_layer_settings", text="", icon="TRIA_DOWN" if settings_open else "TRIA_RIGHT")
        arrow.key = settings_key
        row.label(text="Layer Settings")

        if settings_open:
            box = layout.box()
            box.label(text="Layer Settings Menu")


   