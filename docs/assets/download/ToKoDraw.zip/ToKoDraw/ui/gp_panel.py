

import bpy

class td_PT_greasepencil(bpy.types.Panel):
    bl_label = "Grease Pencil Layers"
    bl_idname = "td_PT_greasepencil"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "ToKoDraw"
    bl_description = "Create a new GP Object"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(setd, context):
        layout = setd.layout



        col = layout.column()
        col.label(text="Grease Pencil Object")
        col.operator("td.gp_create_object", text="Create an GP Object")



        obj = context.object
        if not obj or obj.type != 'GPENCIL':
            col.label(text="Any GP Object selected", icon='INFO')
            return


        col.separator()
        col.label(text="GP Layer")
        col.template_list("td_UL_gp_layers", "", context.object.data, "layers", context.object.data.layers, "active_index")

        row = col.row()
        row.operator("td.gp_add_layer", text="Add")
        row.operator("td.gp_remove_layer", text="Remove")


        col.separator()
        col.label(text="Layer properties")
        col.prop(context.object.data.layers.active, "opacity", text="Opacité")
        col.prop(context.object.data.layers.active, "blend_mode", text="Blend mode")


        col.separator()
        col.label(text="Work Mode")
        col.operator("td.gp_mode", text="Stroke Mode (GP)")
        col.operator("td.td_mode", text="Paint Mode (td)")
