import bpy
from bpy.types import Operator, Panel

from ..core.layer_utils import (
    get_active_layer_group,
    get_active_layer_tex_node,
    get_active_layer_image,
    get_hardalpha_node,
)

from ..core.layer_chain_utils import get_layer_chain

from ..core.layer_drawers import (
    draw_image_source, 
    draw_normalmap_settings,
)    

from ..operators.layer_settings import (
    td_OT_toggle_layer_visibility,
    td_OT_toggle_layer_solo,
    td_OT_rename_layer,
    td_OT_toggle_lock_alpha,
    td_OT_toggle_lock_layer,
    td_OT_duplicate_layer,
)

from ..operators.merge_layers import (
    td_OT_merge_visible_layers_info,
    td_OT_merge_visible_layers,
    td_OT_bake_simple,
)

from ..operators.normal_settings import (
    td_OT_normal_import,
    td_OT_normal_rename,
    td_OT_normal_remove,
)






class td_PT_panel(Panel):
    bl_label = "ToKoDraw Canvas"
    bl_idname = "td_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "ToKoDraw"

    @classmethod
    def poll(cls, context):
        obj = context.object
        return True


    def draw(setd, context):
        layout = setd.layout
        obj = context.object
        scene = context.scene








        box = layout.box()
        mat = obj.active_material

 

        if not mat or "td_layer_count" not in mat:
            box.operator("td.create_material_popup", icon="FILE_NEW")
            layout.separator(factor=1.2)
            return

    

        box.operator("td.remove_material", icon="TRASH")
        layout.separator(factor=1.2)




        box = layout.box()
        row = box.row()
        row.prop(scene.td_general, "mode_selector", text="Mode")



        layout.separator(factor=1.2)







        if scene.td_obj_transform_panel and context.object:


            layout.prop(scene, "td.obj_transform", text="Obj transform", icon="TRIA_DOWN" if scene.td_obj_transform_panel else "TRIA_RIGHT")

            if scene.td_obj_transform_panel:
                obj = context.object

                box = layout.box()


                split = box.split(factor=0.5)

                col_left = split.column()
                col_right = split.column()

                


                col_left.label(text="Location")
                col_left.prop(obj, "location", text="")


                col_right.label(text="Rotation")
                col_right.prop(obj, "rotation_euler", text="")

                box.operator("td.reset_transform", text="Reset", icon="LOOP_BACK")
               






                











        layout.prop(
            scene,
            "td_show_layers_section",
            text="Layers",
            icon="TRIA_DOWN" if scene.td_show_layers_section else "TRIA_RIGHT"
        )

        if scene.td_show_layers_section:


            box = layout.box()




            split = box.split(factor=0.5, align=True)


            left = split.row(align=True)
            left.operator("td.choose_layer_size", text="", icon="ADD")
            left.operator("td.remove_layer", text="", icon="TRASH")
            left.operator("td.move_layer_up", text="", icon="TRIA_UP")
            left.operator("td.move_layer_down", text="", icon="TRIA_DOWN")


            right = split.row(align=True)
            right.alignment = 'RIGHT'
            right.operator("td.merge_visible_layers", text="", icon="IMAGE_DATA")


            col = box.column()

            


            if scene.td_active_layer:
                col.prop(scene, "td_active_opacity", text="Opacity")
            else:
                col.label(text="Select a layer.")


            if not obj or obj.type != 'MESH':
                col.label(text="Select a mesh.")
                return

            mat = obj.active_material
            if not mat or not mat.node_tree:
                col.label(text="No ToKoDraw material.")
                return


            if scene.td_active_layer:

                layer_node = get_active_layer_group(context)

                if layer_node:

                    ha_node = next(
                        (n for n in layer_node.node_tree.nodes
                        if n.type == "GROUP" and n.get("td_feature") == "HARD_ALPHA"),
                        None
                    )

                    if ha_node:
                        col.prop(
                            ha_node.inputs["Threshold"],
                            "default_value",
                            text="Hard Alpha"
                        )
                    else:
                        col.label(text="Hard Alpha node missing.", icon="ERROR")



            layers = get_layer_chain(mat)


            layers = list(reversed(layers))  

            

            for i, layer in enumerate(layers):


                if not layer.node_tree:
                    continue

                internal_name = layer.node_tree.name
                
                rename = layer.get("td_ui_name", None)

                ui_name = layer.label
                layer_name = rename if rename else ui_name

                col = box.column(align=True)
                row = col.row(align=True)


                lock_layer = layer.node_tree.get("td_lock_layer", False)


                row.enabled = not lock_layer
                

                lock_layer = layer.node_tree.get("td_lock_layer", False)


                layer_uid = layer.get("td_uid")
                merge_item = scene.td_merge_map.get(layer_uid)


                row_main = col.row(align=True)

                row_main.context_pointer_set("td_layer", layer)
                
                row_main.enabled = not lock_layer


                row_check = row_main.row(align=True)

                if merge_item:
                    row_check.prop(merge_item, "checked", text="")
                else:
                    row_check.label(text="", icon="BLANK1")
                

                row_radio = row_main.row(align=True)
                op = row_radio.operator(
                    "td.select_layer",
                    text=layer_name,
                    icon='RADIOBUT_ON' if scene.td_active_layer == internal_name else 'RADIOBUT_OFF'
                )
                op.layer_name = internal_name
                op.layer_uid = layer.get("td_uid")
                

                layer_key = f"{internal_name}_open"
                layer_open = bool(scene.get(layer_key, False))

                row_arrow = row_main.row(align=True)
                if scene.td_active_layer == internal_name:
                    arrow = row_arrow.operator(
                        "td.open_layer_settings",
                        text="",
                        icon="TRIA_DOWN" if layer_open else "TRIA_RIGHT"
                    )
                    arrow.key = layer_key
                else:
                    row_arrow.label(text="", icon="TRIA_RIGHT")






                pic = col.row(align=True)



                sub = pic.row(align=True)


                tex_node = next(
                    (n for n in layer.node_tree.nodes if n.type == 'TEX_IMAGE'),
                    None
                )

                icon = "HIDE_OFF" if (tex_node and not tex_node.mute) else "HIDE_ON"

                op = sub.operator("td.toggle_layer_visibility", text="", icon=icon)
                op.layer_name = internal_name

                """

                sub = pic.row(align=True)


                def is_layer_solo(layer):

                    tex_current = next(
                        (n for n in layer.node_tree.nodes if n.type == 'TEX_IMAGE'),
                        None
                    )
                    if not tex_current:
                        return False


                    if tex_current.mute:
                        return False


                    for other in layers:
                        if other == layer:
                            continue

                        tex_other = next(
                            (n for n in other.node_tree.nodes if n.type == 'TEX_IMAGE'),
                            None
                        )
                        if tex_other and not tex_other.mute:
                            return False

                    return True


                icon = "SOLO_ON" if is_layer_solo(layer) else "SOLO_OFF"

                op = sub.operator("td.toggle_layer_solo", text="", icon=icon)
                op.layer_name = internal_name

                """


                
                sub = pic.row(align=True)


                lock = layer.node_tree.get("td_lock_alpha", False)

                icon = "LOCKED" if lock else "UNLOCKED"

                op = sub.operator("td.toggle_lock_alpha", text="", icon=icon)
                op.layer_name = internal_name





                sub = pic.row(align=True)

                lock_layer = layer.node_tree.get("td_lock_layer", False)
                icon = "LOCKVIEW_ON" if lock_layer else "LOCKVIEW_OFF"

                op = sub.operator("td.toggle_lock_layer", text="", icon=icon)
                op.layer_name = internal_name


                sub = pic.row(align=True)
                dup = sub.operator("td.duplicate_layer", text="", icon="DUPLICATE")
                dup.layer_name = layer.get("td_uid")



                sub = pic.row(align=True)
                rename = sub.operator("td.rename_layer", text="", icon="GREASEPENCIL")
                rename.layer_name = layer.get("td_uid")






                if layer_open and scene.td_active_layer == internal_name:

                    box = col.box()

                    box.label(text=f"Menu for {layer_name}")

                    layer_node = layer


                    if not layer_node.node_tree:
                        box.label(text="Invalid layer (no node tree).")
                        continue


                    img_key = f"{internal_name}_img"
                    img_open = bool(scene.get(img_key, False))

                    row = box.row()
                    arrow = row.operator("td.open_layer_settings", text="", icon="TRIA_DOWN" if img_open else "TRIA_RIGHT")
                    arrow.key = img_key
                    row.label(text="Image")

                    if img_open:
                        sub = box.box()
                        sub.label(text="Image Settings")


                        draw_image_source(sub, layer_node)


                        layer_uid = layer_node.get("td_uid")
                        tex_node = next(
                            (n for n in layer_node.node_tree.nodes
                            if n.type == 'TEX_IMAGE' and n.get("td_uid") == layer_uid),
                            None
                        )

                        if not tex_node:
                            sub.label(text="No Texture Node found", icon="ERROR")
                        else:
                            img = tex_node.image
                            iu = tex_node.image_user

                            sub.label(text="Source Settings", icon="FILE")


                            row = sub.row()
                            row.label(text="Source Type:")
                            row.label(text=img.source.replace("_", " ").title())


                            
                            sub.prop(img, "filepath", text="Path")


                            if img.source == 'SEQUENCE':
                                sub.prop(img, "filepath", text="Path")

                                sub.label(text="Sequence Settings", icon="SEQUENCE")
                                sub.prop(iu, "frame_duration", text="Frame Duration")
                                sub.prop(iu, "frame_start", text="Start Frame")
                                sub.prop(iu, "frame_offset", text="Offset")
                                sub.prop(iu, "use_cyclic", text="Cyclic")
                                sub.prop(iu, "use_auto_refresh", text="Auto Refresh")


                            elif img.source == 'GENERATED' or img.source == 'SINGLE_IMAGE':
                                sub.label(text="Generated Image", icon="IMAGE")
                                sub.prop(img, "generated_type", text="Type")
                                sub.prop(img, "generated_width", text="Width")
                                sub.prop(img, "generated_height", text="Height")
                                sub.prop(img, "generated_color", text="Color")
                    

                    tr_key = f"{internal_name}_transform"
                    tr_open = bool(scene.get(tr_key, False))

                    row = box.row()
                    arrow = row.operator("td.open_layer_settings", text="", icon="TRIA_DOWN" if tr_open else "TRIA_RIGHT")
                    arrow.key = tr_key
                    row.label(text="Transform")

                    if tr_open:
                        sub = box.box()
                        sub.label(text="Transform Settings")


                        layer_uid = layer.get("td_uid")
                        if not layer_uid:
                            sub.label(text="Layer UID missing.", icon="ERROR")
                            return

                        if not layer_node or not layer_node.node_tree:
                            sub.label(text="Invalid layer node.", icon="ERROR")
                            return

                        nodes = layer_node.node_tree.nodes
                        mapping = next(
                            (n for n in nodes
                            if n.get("td_feature") == "td_MAPPING"
                            and n.get("td_layer_uid") == layer_uid),
                            None
                        )

                        if mapping is None:
                            sub.label(text="Mapping node missing.", icon="ERROR")
                            return


                        sub.prop(mapping, "vector_type", text="Type")

                        if "Location" in mapping.inputs:
                            sub.prop(mapping.inputs["Location"], "default_value", text="Location")

                        if "Rotation" in mapping.inputs:
                            sub.prop(mapping.inputs["Rotation"], "default_value", text="Rotation")

                        if "Scale" in mapping.inputs:
                            sub.prop(mapping.inputs["Scale"], "default_value", text="Scale")






            mat = obj.active_material
            nt = mat.node_tree if mat else None

            is_bsdf = False

            if nt:

                output = next((n for n in nt.nodes if n.type == 'OUTPUT_MATERIAL'), None)

                if output:

                    link = next((l for l in nt.links if l.to_node == output and l.to_socket.name == "Surface"), None)

                    if link:

                        is_bsdf = (link.from_node.type == 'BSDF_PRINCIPLED')

            nm_key = "td_normalmap_open"
            nm_open = bool(scene.get(nm_key, False))


            col = box.column(align=True)
            row = col.row(align=True)

            row.enabled = is_bsdf


            row.label(
                text="Normal Map",
                icon='RADIOBUT_ON' if is_bsdf else 'RADIOBUT_OFF'  
            )


            row.enabled = is_bsdf
            arrow_icon = "TRIA_RIGHT"

            arrow = row.operator("td.open_layer_settings", text="", icon="TRIA_DOWN" if nm_open else "TRIA_RIGHT")
            arrow.key = nm_key

            if nm_open:
                draw_normalmap_settings(layout, scene, obj)





            split = box.split(factor=0.5, align=True)


            left = split.row(align=True)
            left.operator("td.choose_layer_size", text="", icon="ADD")
            left.operator("td.remove_layer", text="", icon="TRASH")
            left.operator("td.move_layer_up", text="", icon="TRIA_UP")
            left.operator("td.move_layer_down", text="", icon="TRIA_DOWN")


            right = split.row(align=True)
            right.alignment = 'RIGHT'
            right.operator("td.merge_visible_layers", text="", icon="IMAGE_DATA")







        box = layout.box()
        row = box.row(align=True)


        row.prop(mat, "use_backface_culling", text="", icon="MOD_WIREFRAME")
        row.operator("td.render_switch", text="", icon="RESTRICT_RENDER_OFF")


        row.label(text="   ")


        row.operator("td.outline", text="", icon="MOD_SOLIDIFY")
        row.operator("td.lineart", text="", icon="OUTLINER_DATA_GREASEPENCIL")


        row.label(text="   ")


        row.operator("td.set_camera_view", text="", icon="VIEW_CAMERA")
        row.operator("td.obj_transform", text="", icon="EMPTY_AXIS")
        row.operator("view3d.view_selected", text="", icon="VIEWZOOM")


        """       





     
        layout.prop(
            scene,
            "td_show_utils_section",
            text="Utilities",
            icon="TRIA_DOWN" if scene.td_show_utils_section else "TRIA_RIGHT"
        )

        if scene.td_show_utils_section:
            box = layout.box()
            col = box.column()

            col.label(text="Lasso Select")
            col.operator(
                "td.lasso_select",
                text="Lasso select",
                
            ) 
                

            col.label(text="Tools & Maintenance")
            col.operator(
                "td.bake_simple",
                text="Fusion Layers",
                icon="RENDER_STILL"
            )
            col.operator("td.reset_popups", icon="FILE_REFRESH")
            """