import bpy

from ..effects.filter import (
    td_OT_apply_tone_settings,
)






def draw_layer_context_menu(setd, context):
    layout = setd.layout
    scene = context.scene
    
    layer = getattr(context, "td_layer", None)
    if not layer:
        layout.label(text="No layer", icon="ERROR")
        return


    layout.operator("td.open_filter_window", text="Filter", icon="FILTER")


    layout.operator("td.open_transform_window", text="Transform Settings", icon="ORIENTATION_GLOBAL")


    layout.operator("td.open_blend_window", text="Blending Settings", icon="SHADING_TEXTURE")










class td_OT_open_filter_window(bpy.types.Operator):
    bl_idname = "td.open_filter_window"
    bl_label = "Open Filter Window"

    def execute(setd, context):
        bpy.ops.wm.call_panel(name="td_PT_filter_window")
        return {'FINISHED'}





class td_PT_filter_window(bpy.types.Panel):
    bl_idname = "td_PT_filter_window"
    bl_label = "Filters"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'

    def draw(setd, context):
        layout = setd.layout

        col = layout.column(align=True)
        col.operator("td.open_tone_settings", text="Tone Settings")

        col.operator("td.open_color_settings", text="Color Settings")

        col.operator("td.open_sharpen_settings", text="Blur / Sharpen Settings")






class td_OT_open_tone_settings(bpy.types.Operator):
    bl_idname = "td.open_tone_settings"
    bl_label = "Open Tone settings Window"

    def execute(setd, context):
        bpy.ops.wm.call_panel(name="td_tone_settings")
        return {'FINISHED'}




class td_OT_open_color_settings(bpy.types.Operator):
    bl_idname = "td.open_color_settings"
    bl_label = "Open Color settings Window"

    def execute(setd, context):
        bpy.ops.wm.call_panel(name="td_color_settings")
        return {'FINISHED'}




class td_OT_open_sharpen_settings(bpy.types.Operator):
    bl_idname = "td.open_sharpen_settings"
    bl_label = "Open Sharpen settings Window"

    def execute(setd, context):
        bpy.ops.wm.call_panel(name="td_sharpen_settings")
        return {'FINISHED'}








class td_PT_tone_settings_window(bpy.types.Panel):
    bl_idname = "td_tone_settings"
    bl_label = "Tone settings"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'

    def draw(setd, context):
        layout = setd.layout
        scene = context.scene
        

        if not layer_name:
            setd.report({'ERROR'}, "No clicked layer stored")
            return {'CANCELLED'}
        
        col = layout.column(align=True)
        col.label(text="Brightness / Contrast")
        col.prop(scene, "td_brightness")
        col.prop(scene, "td_contrast")

        col.separator()

        col.label(text="Gamma")
        col.prop(scene, "td_gamma")

        col.separator()

        col.label(text="Luminance Gain")
        col.prop(scene, "td_gain")

        col.separator()

        col.operator("td.apply_tone_settings", text="Apply", icon="CHECKMARK")


        

class td_PT_color_settings_window(bpy.types.Panel):
    bl_idname = "td_color_settings"
    bl_label = "Color settings"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'

    def draw(setd, context):
        layout = setd.layout

        col = layout.column(align=True)
        col.label (text="boulilouloiu")


class td_PT_sharpen_settings_window(bpy.types.Panel):
    bl_idname = "td_sharpen_settings"
    bl_label = "Sharpen settings"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'

    def draw(setd, context):
        layout = setd.layout

        col = layout.column(align=True)
        col.label (text="rezauaeieuy")









class td_OT_open_transform_window(bpy.types.Operator):
    bl_idname = "td.open_transform_window"
    bl_label = "Open transform window"

    def execute(setd, context):
        bpy.ops.wm.call_panel(name="td_PT_transform_window")
        return {'FINISHED'}




class td_PT_Transform_window(bpy.types.Panel):
    bl_idname = "td_PT_transform_window"
    bl_label = "Transforms"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'

    def draw(setd, context):
        layout = setd.layout

        col = layout.column(align=True)
        col.label(text="transform UV")
        col.label(text="Scale layer")
        col.label(text="...")










class td_OT_open_blend_window(bpy.types.Operator):
    bl_idname = "td.open_blend_window"
    bl_label = "Open blend Window"

    def execute(setd, context):
        bpy.ops.wm.call_panel(name="td_PT_blend_window")
        return {'FINISHED'}





class td_PT_Blend_window(bpy.types.Panel):
    bl_idname = "td_PT_blend_window"
    bl_label = "Blend"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'

    def draw(setd, context):
        layout = setd.layout

        col = layout.column(align=True)
        col.label(text="Hard Alpha")
        col.label(text="...")
        col.label(text="...")