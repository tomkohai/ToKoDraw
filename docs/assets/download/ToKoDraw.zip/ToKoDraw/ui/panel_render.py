import bpy
from bpy.types import Panel





class td_PT_render_tools(Panel):
    bl_label = "Render Tools"
    bl_idname = "td_PT_render_tools"
    bl_parent_id = "td_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "ToKoDraw"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(setd, context):
        layout = setd.layout
        obj = context.object
        scene = context.scene

        if not obj or not obj.active_material:
            layout.label(text="No material.")
            return

        mat = obj.active_material

        layout.prop(mat, "use_backface_culling", text="Backface Culling")


        layout.operator(
            "td.render_switch",
            text="Render Switch",
            icon="RESTRICT_RENDER_OFF"
        )
        






