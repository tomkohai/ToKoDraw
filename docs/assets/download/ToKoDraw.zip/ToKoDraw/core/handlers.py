import bpy

def td_lock_alpha_handler(scene):

    if bpy.context.mode != 'PAINT_TEXTURE':
        return

    context = bpy.context
    tool = context.tool_settings


    brush = tool.image_paint.brush
    if not brush:
        return


    active_layer = scene.get("td_active_layer", None)
    if not active_layer:
        return


    mat = context.object.active_material
    if not mat or not mat.node_tree:
        return

    nodes = mat.node_tree.nodes


    layer_node = nodes.get(active_layer)
    if not layer_node or not layer_node.node_tree:
        return





    lock_alpha = layer_node.node_tree.get("td_lock_alpha", False)


    prev_brush = scene.get("td_prev_brush", None)
    if prev_brush != brush.name:
        scene["td_prev_brush"] = brush.name


    if lock_alpha:
        if "td_prev_brush_alpha" not in scene:
            scene["td_prev_brush_alpha"] = brush.use_alpha

        if brush.use_alpha:
            brush.use_alpha = False


    else:
        prev = scene.get("td_prev_brush_alpha", None)
        if prev is not None:
            brush.use_alpha = prev






    lock_layer = layer_node.node_tree.get("td_lock_layer", False)

    if lock_layer:

        if "td_prev_brush_strength" not in scene:
            scene["td_prev_brush_strength"] = brush.strength


        if brush.strength != 0.0:
            brush.strength = 0.0

    else:

        prev_strength = scene.get("td_prev_brush_strength", None)
        if prev_strength is not None:
            brush.strength = prev_strength


        if "td_prev_brush_strength" in scene:
            del scene["td_prev_brush_strength"]







def td_sync_lineart_name(scene):
    for obj in scene.objects:
        if obj.type == 'MESH':


            if not hasattr(obj, "name_old") or obj.name_old == "":
                obj.name_old = obj.name
                continue
                
            la_old = bpy.data.objects.get(f"td_LineArt_{obj.name_old}") if hasattr(obj, "name_old") else None
            la_new = bpy.data.objects.get(f"td_LineArt_{obj.name}")


            if la_old and not la_new:
                la_old.name = f"td_LineArt_{obj.name}"
                obj.name_old = obj.name

def td_sync_outline_name(scene):
    for obj in scene.objects:
        if obj.type != 'MESH':
            continue


        if not hasattr(obj, "name_old") or obj.name_old == "":
            obj.name_old = obj.name
            continue


        if obj.name != obj.name_old:


            if bpy.data.objects.get(obj.name_old) is None:

                old_name = f"{obj.name_old}_Outline"
                new_name = f"{obj.name}_Outline"

                outline_obj = bpy.data.objects.get(old_name)
                if outline_obj:
                    outline_obj.name = new_name


            obj.name_old = obj.name


def fix_lineart_material(scene):
    for obj in scene.objects:
        if obj.type == 'GPENCIL' and obj.name.startswith("td_LineArt_"):
            mat = bpy.data.materials.get("td_LineArt_Black")
            if not mat:
                continue

            mat_index = obj.data.materials.find(mat.name)
            if mat_index == -1:
                continue


            for layer in obj.data.layers:
                for frame in layer.frames:
                    for stroke in frame.strokes:
                        stroke.material_index = mat_index



