
from uuid import uuid4

import bpy

def get_group(name):
    if name in bpy.data.node_groups:
        return bpy.data.node_groups[name]
    return bpy.data.node_groups.new(name, 'ShaderNodeTree')


def create_Hard_Alpha(index, mat_index, layer_uid):

    name = f"td{mat_index}_HA_{index}_{layer_uid[:8]}"


    group = bpy.data.node_groups.new(name, 'ShaderNodeTree')
    group["td_index"] = index
    group["td_layer_uid"] = layer_uid  
    group["td_feature"] = "HARD_ALPHA"


    iface = group.interface
    nodes = group.nodes
    links = group.links
    nodes.clear()
    iface.clear()


    iface.new_socket(name="Alpha", in_out='INPUT', socket_type='NodeSocketFloat', description="")

    th = iface.new_socket(name="Threshold", in_out='INPUT', socket_type='NodeSocketFloat', description="")
    th.min_value = 0.0
    th.max_value = 0.999
    th.default_value = 0.0

    iface.new_socket(name="AlphaClean", in_out='OUTPUT', socket_type='NodeSocketFloat', description="")


    node_in = nodes.new("NodeGroupInput")
    node_in.location = (-400, 0)

    node_out = nodes.new("NodeGroupOutput")
    node_out.location = (400, 0)


    gt = nodes.new("ShaderNodeMath")
    gt.operation = 'GREATER_THAN'
    gt.location = (-100, -100)

    mul = nodes.new("ShaderNodeMath")
    mul.operation = 'MULTIPLY'
    mul.location = (150, -100)


    links.new(node_in.outputs["Alpha"], gt.inputs[0])
    links.new(node_in.outputs["Threshold"], gt.inputs[1])
    links.new(gt.outputs[0], mul.inputs[0])
    links.new(node_in.outputs["Alpha"], mul.inputs[1])
    links.new(mul.outputs[0], node_out.inputs["AlphaClean"])

    return group


def create_td_layer(mat_index, index, size=2048):



    layer_uid = uuid4().hex


    
    name = f"td{mat_index}_Layer_{index}"


    ng = bpy.data.node_groups.new(name, 'ShaderNodeTree')


    ng["td_uid"] = layer_uid

    ng["td_index"] = index



    ng["td_lock_alpha"] = False      


    ng["td_lock_layer"] = False


    scene = bpy.context.scene


    item = scene.td_merge_map.add()
    item.name = layer_uid


    ng.nodes.clear()
    ng.interface.clear()

    nodes = ng.nodes
    links = ng.links
    iface = ng.interface


    n_in = nodes.new("NodeGroupInput")
    n_in.location = (0, 150)

    n_out = nodes.new("NodeGroupOutput")
    n_out.location = (1200, 0)


    ng.interface.new_socket(
        name="Opacity",
        in_out='INPUT',
        socket_type="NodeSocketFloat"
    )

    s = ng.interface.new_socket(
        name="Settings",
        in_out='INPUT',
        socket_type="NodeSocketFloat"
    )

    s.min_value = 0.0
    s.max_value = 0.95



    ng.interface.new_socket(
        name="Color",
        in_out='OUTPUT',
        socket_type="NodeSocketColor"
    )

    ng.interface.new_socket(
        name="Alpha",
        in_out='OUTPUT',
        socket_type="NodeSocketFloat"
    )

    

    texcoord = nodes.new("ShaderNodeTexCoord")
    texcoord.location = (-750, 0)



    mapping = nodes.new("ShaderNodeMapping")
    mapping.location = (-625, 0)
    mapping.inputs["Scale"].default_value = (1.0, 1.0, 1.0)
    mapping.inputs["Rotation"].default_value = (0.0, 0.0, 0.0)
    mapping.inputs["Location"].default_value = (0.0, 0.0, 0.0)
    mapping["td_feature"] = "td_MAPPING"


    tex = nodes.new("ShaderNodeTexImage")
    tex.name = "Texture"
    tex.label = f"Layer {index}"
    tex.location = (-500, 0)
    

    tex.interpolation = 'Closest'


    
    from ..core.layer_utils import create_texture_layer
    is_first_layer = (index == 0)

    layer_display_name = f"td{mat_index}_IMG_{index}"

    tex.image = create_texture_layer(
        mat_index,
        index,
        layer_uid,
        layer_display_name,
        is_first_layer,
        size=size  
    )

    img = tex.image
    img.update()
    img.pack()
    

    tex["td_uid"] = layer_uid
    tex["td_index"] = index
    
    
   

    mapping["td_layer_uid"] = layer_uid
    mapping["td_index"] = index



    HardAlpha = nodes.new("ShaderNodeGroup")
    HardAlpha.node_tree = create_Hard_Alpha(index, mat_index, layer_uid)  
    HardAlpha.label = "Hard Alpha"
    HardAlpha["td_feature"] = "HARD_ALPHA"

    HardAlpha.location = (-200, 100)


    HardAlpha["td_index"] = index



    mul = nodes.new("ShaderNodeMath")
    mul.operation = 'MULTIPLY'
    mul.location = (200, 150)


   

    links.new(texcoord.outputs["UV"], mapping.inputs["Vector"])
    links.new(mapping.outputs["Vector"], tex.inputs["Vector"])
    

    links.new(tex.outputs["Alpha"], HardAlpha.inputs["Alpha"])
    links.new(n_in.outputs["Opacity"], mul.inputs[1])
    links.new(HardAlpha.outputs["AlphaClean"], mul.inputs[0])      
       


    links.new(tex.outputs["Color"], n_out.inputs["Color"])
    links.new(mul.outputs["Value"], n_out.inputs["Alpha"])

    return ng, layer_uid






def create_td_nbadd(mat_index, index):
    name = f"td{mat_index}_NBAdd_{index}"


    group = bpy.data.node_groups.new(name, 'ShaderNodeTree')

    group["td_index"] = index          
    group["td_uid"] = uuid4().hex      

    iface = group.interface
    nodes = group.nodes
    links = group.links
    nodes.clear()


    iface.new_socket(name="Below_Color", in_out='INPUT', socket_type="NodeSocketColor", description="")
    iface.new_socket(name="Below_Alpha", in_out='INPUT', socket_type="NodeSocketFloat", description="")
    iface.new_socket(name="Layer_Color", in_out='INPUT', socket_type="NodeSocketColor", description="")
    iface.new_socket(name="Layer_Alpha", in_out='INPUT', socket_type="NodeSocketFloat", description="")


    iface.new_socket(name="Out_Color", in_out='OUTPUT', socket_type="NodeSocketColor", description="")
    iface.new_socket(name="Out_Alpha", in_out='OUTPUT', socket_type="NodeSocketFloat", description="")

    n_in = nodes.new("NodeGroupInput")
    n_in.location = (-800, 0)

    n_out = nodes.new("NodeGroupOutput")
    n_out.location = (600, 0)


    inv_a = nodes.new("ShaderNodeMath")
    inv_a.operation = 'SUBTRACT'
    inv_a.inputs[0].default_value = 1.0
    inv_a.location = (-500, 150)
    links.new(n_in.outputs["Layer_Alpha"], inv_a.inputs[1])

    mul_below = nodes.new("ShaderNodeVectorMath")
    mul_below.operation = 'MULTIPLY'
    mul_below.location = (-300, 150)
    links.new(n_in.outputs["Below_Color"], mul_below.inputs[0])
    links.new(inv_a.outputs[0],            mul_below.inputs[1])

    mul_above = nodes.new("ShaderNodeVectorMath")
    mul_above.operation = 'MULTIPLY'
    mul_above.location = (-300, -50)
    links.new(n_in.outputs["Layer_Color"], mul_above.inputs[0])
    links.new(n_in.outputs["Layer_Alpha"], mul_above.inputs[1])

    add_color = nodes.new("ShaderNodeVectorMath")
    add_color.operation = 'ADD'
    add_color.location = (-50, 50)
    links.new(mul_below.outputs[0], add_color.inputs[0])
    links.new(mul_above.outputs[0], add_color.inputs[1])


    inv_base = nodes.new("ShaderNodeMath")
    inv_base.operation = 'SUBTRACT'
    inv_base.inputs[0].default_value = 1.0
    inv_base.location = (-500, -350)
    links.new(n_in.outputs["Below_Alpha"], inv_base.inputs[1])

    mul_alpha = nodes.new("ShaderNodeMath")
    mul_alpha.operation = 'MULTIPLY'
    mul_alpha.location = (-300, -350)
    links.new(n_in.outputs["Layer_Alpha"], mul_alpha.inputs[0])
    links.new(inv_base.outputs[0],         mul_alpha.inputs[1])

    add_alpha = nodes.new("ShaderNodeMath")
    add_alpha.operation = 'ADD'
    add_alpha.location = (-50, -350)
    links.new(n_in.outputs["Below_Alpha"], add_alpha.inputs[0])
    links.new(mul_alpha.outputs[0],        add_alpha.inputs[1])

    links.new(add_color.outputs[0], n_out.inputs["Out_Color"])
    links.new(add_alpha.outputs[0], n_out.inputs["Out_Alpha"])

    return group





def create_ToKoDraw_group(mat, layer_count=2, td_id="", mat_index=0):

    tree = mat.node_tree
    nodes = tree.nodes
    links = tree.links

    mat["td_id"] = td_id



    nodes.clear()


    prev_color = None
    prev_alpha = None

    x_layer = -1200
    x_nbadd = -900

    for i in range(layer_count):

        y = 200 - i * 200


        ng, layer_uid = create_td_layer(mat_index, i)
        layer = nodes.new("ShaderNodeGroup")
        layer.node_tree = ng
        layer.inputs["Opacity"].default_value = 1.0



        layer["td_uid"] = layer_uid          
        layer["td_index"] = i

        layer.name = f"td{mat_index}_Layer_{i}"
        layer.label = f"td_Layer_{i}"

       
        if i == 0:

            prev_color = layer.outputs["Color"]
            prev_alpha = layer.outputs["Alpha"]
        else:

            nbadd = nodes.new("ShaderNodeGroup")
            nbadd.node_tree = create_td_nbadd(mat_index, i)
            nbadd.location = (x_nbadd, y)


            nbadd_uid = uuid4().hex
            nbadd["td_uid"] = nbadd_uid
            nbadd["td_index"] = i



            nbadd.name = f"td{mat_index}_NBAdd_{i}"


            links.new(prev_color, nbadd.inputs["Below_Color"])
            links.new(prev_alpha, nbadd.inputs["Below_Alpha"])
            links.new(layer.outputs["Color"], nbadd.inputs["Layer_Color"])
            links.new(layer.outputs["Alpha"], nbadd.inputs["Layer_Alpha"])

            prev_color = nbadd.outputs["Out_Color"]
            prev_alpha = nbadd.outputs["Out_Alpha"]



    em = nodes.new("ShaderNodeEmission")
    em.location = (-200, 0)

    mixshad = nodes.new("ShaderNodeMixShader")
    mixshad.location = (0, 0)

    tbsdf = nodes.new("ShaderNodeBsdfTransparent")
    tbsdf.location = (-200, 150)

    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.location = (-200, -150)




    links.new(prev_color, em.inputs["Color"])
    links.new(em.outputs["Emission"], mixshad.inputs["Shader_001"])


    links.new(tbsdf.outputs["BSDF"], mixshad.inputs["Shader"])


    links.new(prev_alpha, mixshad.inputs["Fac"]) 


    links.new(prev_color, bsdf.inputs["Base Color"])
    links.new(prev_alpha, bsdf.inputs["Alpha"])




    frame_normal = nodes.new("NodeFrame")
    frame_normal.label = "Normal Map – UV Mapping & Normal Vector Transform"
    frame_normal.location = (-450, -850)
    frame_normal.shrink = True



    texcoord = nodes.new("ShaderNodeTexCoord")
    texcoord.location = (-400, -825)
    texcoord.parent = frame_normal


    mapping_uv = nodes.new("ShaderNodeMapping")
    mapping_uv.location = (-200, -825)
    mapping_uv.parent = frame_normal


    normal_tex = nodes.new("ShaderNodeTexImage")
    normal_tex.location = (0, -925)
    normal_tex.interpolation = 'Linear'
    normal_tex.parent = frame_normal

    normal_tex["td_is_normal"] = True



    normal_map = nodes.new("ShaderNodeNormalMap")
    normal_map.location = (-250, -550)
    normal_map.inputs["Strength"].default_value = 1.0
    normal_map.space = 'TANGENT'
    normal_map.parent = frame_normal
    


    mapping_normal = nodes.new("ShaderNodeMapping")
    mapping_normal.location = (-50, -550)
    mapping_normal.parent = frame_normal


    links.new(texcoord.outputs["UV"], mapping_uv.inputs["Vector"])
    links.new(mapping_uv.outputs["Vector"], normal_tex.inputs["Vector"])
    links.new(normal_tex.outputs["Color"], normal_map.inputs["Color"])
    links.new(normal_map.outputs["Normal"], mapping_normal.inputs["Vector"])


    links.new(mapping_normal.outputs["Vector"], bsdf.inputs["Normal"])


    output = nodes.new("ShaderNodeOutputMaterial")
    output.location = (200, 0)

    links.new(mixshad.outputs["Shader"], output.inputs["Surface"])

    

    return None


