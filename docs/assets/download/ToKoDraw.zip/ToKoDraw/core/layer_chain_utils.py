import bpy
from ..core.material_utils import get_active_td_material






def get_layer_chain(mat):


    mat = get_active_td_material()
    if not mat:
        return []

    mat_uid = mat.get("td_mat_uid")
    if not mat_uid:
        return []

    nt = mat.node_tree
    nodes = nt.nodes

    

    all_layers = {
        n.node_tree.name: n
        for n in mat.node_tree.nodes
        if n.type == 'GROUP'
        and n.node_tree
        and n.get("td_index") is not None
        and n.get("td_uid") is not None  
    }


    nbadds = get_nbadd_chain(mat)

    if not nbadds:

        return sorted(all_layers.values(), key=lambda n: n.get("td_index"))




    chain = []


    L0 = next((n for n in all_layers.values() if n.get("td_index") == 0), None)

    if L0:
        chain.append(L0)


    for nb in nbadds:
        inp = nb.inputs.get("Layer_Color")
        if inp and inp.links:
            layer = inp.links[0].from_node


            if layer.get("td_uid") in [n.get("td_uid") for n in all_layers.values()]:
                chain.append(layer)

    return chain






def get_nbadd_chain(mat):

    if not mat:
        return []

  
    nt = mat.node_tree
    nodes = nt.nodes


    nbadds = [
        n for n in nodes
        if n.type == 'GROUP'
        and n.node_tree
        and n.node_tree.get("td_uid") is not None
        and n.node_tree.get("td_index") is not None
    ]

    if not nbadds:

        return []


    uid_layer0 = next(
        n["td_uid"]
        for n in nodes
        if n.type == 'GROUP'
        and n.node_tree
        and n.get("td_index") == 0
        and n.get("td_uid") is not None
    )


    layer0 = next(
        n for n in nodes
        if n.type == 'GROUP'
        and n.node_tree
        and n.get("td_uid") == uid_layer0
    )

    if not layer0:
        return []


    nbadd0 = None
    for n in nbadds:
        below = n.inputs.get("Below_Color")
        if below and below.links:
            from_node = below.links[0].from_node
            if "td_uid" in from_node and from_node["td_uid"] == uid_layer0:
                nbadd0 = n
                break

    if not nbadd0:
        return []

    chain = [nbadd0]


    current = nbadd0

    while True:
        next_nbadd = None

        for n in nbadds:
            if n == current:
                continue

            below = n.inputs.get("Below_Color")
            if below and below.links:
                if below.links[0].from_node == current:
                    next_nbadd = n
                    break

        if next_nbadd:
            chain.append(next_nbadd)
            current = next_nbadd
        else:
            break

    return chain






def get_nbadd_for_layer(mat, layer):
  
    layers = get_layer_chain(mat)
    nbadds = get_nbadd_chain(mat)

    index = layers.index(layer)
    return nbadds[index - 1] if index > 0 else None


    return None

    
    
    




def get_real_layer_nbadd_chain(mat, master_name=None, debug=False):


    if not mat or not mat.node_tree:
        if debug:
            print("No material or node tree")
        return [], []

    nt = mat.node_tree
    nodes = nt.nodes




    layers_all = [
        n for n in nodes
        if n.type == "GROUP"
        and n.node_tree
        and n.get("td_uid") is not None
        and n.get("td_index") is not None
        and "NBAdd" not in n.name
    ]

    if not layers_all:
        return [], []


    layer0 = next((l for l in layers_all if l.get("td_index") == 0), None)
    if not layer0:
        raise RuntimeError("Layer 0 missing — pipeline corrupted")




    nb_chain = get_nbadd_chain(mat)  


    nbadds = [nb for nb in nb_chain if nb.get("td_index") >= 1]




    ordered_layers = [layer0]  

    for nb in nb_chain:

        link = nb.inputs["Layer_Color"].links
        if not link:
            raise RuntimeError("NBAdd missing Layer_Color link — pipeline corrupted")

        layer = link[0].from_node
        ordered_layers.append(layer)

    layers = ordered_layers




    if len(nbadds) != len(layers) - 1:
        raise RuntimeError("Layer/NBAdd mismatch — pipeline corrupted")

    return layers, nbadds





def swap_layer_positions(mat, index_a, index_b):
    layers, nbadds = get_real_layer_nbadd_chain(mat)


    layer_a = layers[index_a]
    layer_b = layers[index_b]

    nb_a = nbadds[index_a - 1] if index_a - 1 < len(nbadds) and index_a > 0 else None
    nb_b = nbadds[index_b - 1] if index_b - 1 < len(nbadds) and index_b > 0 else None


    y_a = layer_a.location.y
    y_b = layer_b.location.y
    layer_a.location.y = y_b
    layer_b.location.y = y_a


    if nb_a and nb_b:
        y_na = nb_a.location.y
        y_nb = nb_b.location.y
        nb_a.location.y = y_nb
        nb_b.location.y = y_na


