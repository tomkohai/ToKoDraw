import bpy

class td_OutlineProps(bpy.types.PropertyGroup):

    outline_exists: bpy.props.BoolProperty(
        name="Outline Exists",
        default=False
    )

    outline_settings_open: bpy.props.BoolProperty(
        name="Outline Settings",
        default=False
    )

    outline_thickness: bpy.props.FloatProperty(
        name="Thickness",
        default=0.02,
        min=0.0,
        max=0.1
    )

    outline_offset: bpy.props.FloatProperty(
        name="Offset",
        default=0.0,
        min=-1.0,
        max=1.0
    )

    