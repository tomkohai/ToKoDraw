import bpy
import sys
import importlib


from .handlers import (
    td_lock_alpha_handler,
    td_sync_lineart_name,
    td_sync_outline_name,
    fix_lineart_material,
)


from .layer_utils import (
    get_active_layer_group,
    get_active_layer_tex_node,
    get_active_layer_image,
    get_hardalpha_node,
)


from .outline_utils import td_OutlineProps


from .node_groups import (
    create_ToKoDraw_group,
    get_group,
    create_Hard_Alpha, 
    create_td_layer, 
    create_td_nbadd,
)

from .normal_color_palette import create_normal_palette

