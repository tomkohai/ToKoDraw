import bpy
from .node_groups import create_ToKoDraw_group

def create_ToKoDraw_material(obj):

    existing = [m.name for m in bpy.data.materials if m.name.startswith("td_Mat_")]
    indices = [int(name.split("_")[-1]) for name in existing] if existing else []
    next_index = max(indices) + 1 if indices else 1

    mat_name = f"td_Mat_{next_index}"
    mat = bpy.data.materials.new(name=mat_name)
    mat.use_nodes = True


    import uuid
    mat["td_mat_uid"] = str(uuid.uuid4())


    mat["td_mat_index"] = next_index
    


    td_id = mat.name_full.replace(" ", "_")
    mat["td_id"] = td_id


    obj.active_material = mat

    nt = mat.node_tree
    nodes = nt.nodes
    links = nt.links
    nodes.clear()


    out = nodes.new("ShaderNodeOutputMaterial")
    out.location = (400, 0)


    create_ToKoDraw_group(
        mat,
        layer_count=2,
        td_id=td_id,
        mat_index=mat["td_mat_index"]
    )

    mat["td_layer_count"] = 2
    

    return mat





def get_active_td_material():
    mat = bpy.context.object.active_material
    if mat and "td_mat_uid" in mat:
        return mat
    return None





def register():
    pass

def unregister():
    pass
