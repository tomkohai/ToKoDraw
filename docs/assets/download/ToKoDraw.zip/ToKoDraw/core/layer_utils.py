import bpy
from ..core.material_utils import get_active_td_material

LAYER_PREFIX = "td_Layer_"

def create_texture_layer(mat_index, index, layer_uid, layer_display_name, is_first_layer, size=2048):


    internal_name = f"td{mat_index}_IMG_{index}"
    display_name  = f"{layer_display_name}"


    for im in bpy.data.images:
        if im.name.startswith("td") and im.users == 0:
            bpy.data.images.remove(im)



    img = bpy.data.images.get(internal_name)
    if img:
        img.name = display_name  
        return img


    img = bpy.data.images.new(
        name=internal_name,
        width=size,
        height=size,
        alpha=True,
        float_buffer=True,   
    )


    img.generated_color = (
        1.0, 1.0, 1.0, 1.0 if is_first_layer else 0.0
    )


    img.colorspace_settings.name = 'sRGB'


    img.update()


    img.pack()



    img["td_index"] = index 
    img["td_uid"] = layer_uid




    return img







def get_active_layer_group(context):

    scene = context.scene
    obj = context.object
    if not obj:
        return None

    mat = get_active_td_material()
    if not mat or not mat.node_tree:
        return None

    active_uid = scene.td_active_layer_uid
    if not active_uid:
        return None


    for n in mat.node_tree.nodes:
        if (
            n.type == 'GROUP'
            and n.node_tree
            and n.get("td_uid") == active_uid
        ):
            return n

    return None







def get_active_layer_tex_node(context):
    


    layer_group = get_active_layer_group(context)
    if not layer_group or not layer_group.node_tree:
        return None


    for n in layer_group.node_tree.nodes:
        if n.type == "TEX_IMAGE":
            return n

    return None




def get_active_layer_image(context):
    

    tex_node = get_active_layer_tex_node(context)
    if not tex_node:
        return None

    return tex_node.image



def get_tex_node_from_layer(layer_node):
    
    if not layer_node or not layer_node.node_tree:
        return None


    if not layer_node.get("td_uid"):
        return None


    for n in layer_node.node_tree.nodes:
        if n.type == "TEX_IMAGE":
            return n

    return None

    





def get_hardalpha_node(layer_node):
    if not layer_node or not layer_node.node_tree:
        return None

    for n in layer_node.node_tree.nodes:
        if n.type == "GROUP" and n.get("td_feature") == "HARD_ALPHA":
            return n

    return None





