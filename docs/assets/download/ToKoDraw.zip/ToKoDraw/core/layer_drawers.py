import bpy
from ..core.layer_utils import (
    get_active_layer_group, 
    get_active_layer_tex_node, 
    get_active_layer_image,
    get_hardalpha_node, 
    
)



def _get_tex_node(layer_node):
    tex_node = None
    for n in layer_node.node_tree.nodes:
        if n.type == "TEX_IMAGE":
            tex_node = n
            break
    return tex_node


def draw_image_source(layout, layer_node):
    tex_node = _get_tex_node(layer_node)
    if not tex_node:
        layout.label(text="No Texture node.", icon="ERROR")
        return

    img = tex_node.image
    
    box = layout.box()
    box.label(text="Image", icon="IMAGE_DATA")
    box.prop(tex_node, "image", text="")


    row = box.row()
    op = row.operator("td.new_image", text="New Image", icon="IMAGE_DATA")
    op.layer_uid = layer_node["td_uid"]



    row = box.row()
    op = row.operator("td.import_image", text="Import Image or sequence", icon="FILEBROWSER")
    op.layer_uid = layer_node.get("td_uid")



    if img:
        box.prop(img, "name", text="Rename")


        row = box.row()
        op = row.operator("td.remove_image", text="Remove Image", icon="TRASH")
        op.layer_uid = layer_node.get("td_uid")



    box2 = layout.box()
    box2.label(text="Texture Settings", icon="TEXTURE")
    box2.prop(tex_node, "interpolation", text="Interpolation")
    box2.prop(tex_node, "projection", text="Projection")
    box2.prop(tex_node, "extension", text="Extension")
    box2.prop(img.colorspace_settings, "name", text="Color Space")
    box2.prop(img, "alpha_mode", text="Alpha Mode")

    







def draw_normalmap_settings(layout, scene, obj):

    def resolve_node(node):
        if node.type == 'FRAME':
            for n in node.nodes:
                if n.type in {'TEX_IMAGE', 'NORMAL_MAP', 'MAPPING'}:
                    return n
        return node

    mat = obj.active_material
    nt = mat.node_tree


    bsdf = next((n for n in nt.nodes if n.type == 'BSDF_PRINCIPLED'), None)

    mapping2 = None
    normalmap = None
    img_normal = None
    mapping1 = None

    if bsdf:
        for link in bsdf.inputs["Normal"].links:
            mapping2 = resolve_node(link.from_node)

    if mapping2:
        for link in mapping2.inputs["Vector"].links:
            normalmap = resolve_node(link.from_node)

    if normalmap:
        for link in normalmap.inputs["Color"].links:
            node = link.from_node
            if node.type == 'FRAME':
                for n in node.nodes:
                    if n.type == 'TEX_IMAGE':
                        img_normal = n
                        break
            elif node.type == 'TEX_IMAGE':
                img_normal = node

    if img_normal:
        for link in img_normal.inputs["Vector"].links:
            mapping1 = resolve_node(link.from_node)




    if scene.td_show_normalmap_panel:

        col = layout.column()
        box = col.box()




        tex_key = "td_normal_tex_open"
        tex_open = bool(scene.get(tex_key, False))

        row = box.row()
        arrow = row.operator("td.open_layer_settings", text="", icon="TRIA_DOWN" if tex_open else "TRIA_RIGHT")
        arrow.key = tex_key
        row.label(text="Normal Texture")

        if tex_open and img_normal:
            sub = box.box()
            sub.prop(img_normal, "image", text="Image")
            sub.prop(img_normal, "interpolation", text="Interpolation")
            sub.prop(img_normal, "extension", text="Extension")

            actions = sub.box()
            actions.label(text="Actions")
            actions.operator("td.normal_import", text="Import", icon="FILE_FOLDER")
            actions.operator("td.normal_rename", text="Rename", icon="FONT_DATA")
            actions.operator("td.normal_remove", text="Remove", icon="TRASH")




        map1_key = "td_normal_mapping1_open"
        map1_open = bool(scene.get(map1_key, False))

        row = box.row()
        arrow = row.operator("td.open_layer_settings", text="", icon="TRIA_DOWN" if map1_open else "TRIA_RIGHT")
        arrow.key = map1_key
        row.label(text="UV Mapping")

        if map1_open and mapping1:
            sub = box.box()
            sub.prop(mapping1.inputs["Location"], "default_value", text="Location")
            sub.prop(mapping1.inputs["Rotation"], "default_value", text="Rotation")
            sub.prop(mapping1.inputs["Scale"], "default_value", text="Scale")




        nm_key = "td_normal_map_open"
        nm_open = bool(scene.get(nm_key, False))

        row = box.row()
        arrow = row.operator("td.open_layer_settings", text="", icon="TRIA_DOWN" if nm_open else "TRIA_RIGHT")
        arrow.key = nm_key
        row.label(text="Normal Map Node")

        if nm_open and normalmap:
            sub = box.box()
            sub.prop(normalmap.inputs["Strength"], "default_value", text="Strength")
            sub.prop(normalmap, "space", text="Space")




        map2_key = "td_normal_mapping2_open"
        map2_open = bool(scene.get(map2_key, False))

        row = box.row()
        arrow = row.operator("td.open_layer_settings", text="", icon="TRIA_DOWN" if map2_open else "TRIA_RIGHT")
        arrow.key = map2_key
        row.label(text="Normal Mapping")

        if map2_open and mapping2:
            sub = box.box()
            sub.prop(mapping2.inputs["Location"], "default_value", text="Location")
            sub.prop(mapping2.inputs["Rotation"], "default_value", text="Rotation")
            sub.prop(mapping2.inputs["Scale"], "default_value", text="Scale")




        bsdf_key = "td_normal_bsdf_open"
        bsdf_open = bool(scene.get(bsdf_key, False))

        row = box.row()
        arrow = row.operator("td.open_layer_settings", text="", icon="TRIA_DOWN" if bsdf_open else "TRIA_RIGHT")
        arrow.key = bsdf_key
        row.label(text="BSDF Settings")

        if bsdf_open and bsdf:
            sub = box.box()
            sub.prop(bsdf.inputs["Metallic"], "default_value", text="Metallic")
            sub.prop(bsdf.inputs["Roughness"], "default_value", text="Roughness")
            sub.prop(bsdf.inputs["IOR"], "default_value", text="IOR")
