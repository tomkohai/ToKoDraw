import bpy
from ..core.material_utils import create_ToKoDraw_material
from ..core.layer_utils import (
    create_texture_layer,
)   
from ..core.layer_chain_utils import (
    get_layer_chain,
    get_nbadd_chain,
)


class td_OT_create_material_popup(bpy.types.Operator):
    bl_idname = "td.create_material_popup"
    bl_label = "Create Material or Canvas"

    paint_mode: bpy.props.EnumProperty(
        name="Workflow",
        items=[
            ('3D', "3D Object", "Paint directly on the mesh"),
            ('2D', "2D Canvas", "Use a 2D canvas plane")
        ],
        default='3D'
    )

    def invoke(setd, context, event):
        return context.window_manager.invoke_props_dialog(setd)

    def draw(setd, context):
        layout = setd.layout
        layout.label(text="Choose your workflow:")
        layout.prop(setd, "paint_mode", expand=True)

    def execute(setd, context):


        selected = context.selected_objects

        if setd.paint_mode == '3D':


            if len(selected) == 0:
                setd.report({'ERROR'}, "Select a mesh to use the 3D workflow.")
                return {'CANCELLED'}

            obj = selected[0]


            if obj.type != 'MESH':
                setd.report({'ERROR'}, "Select a mesh to use the 3D workflow.")
                return {'CANCELLED'}


            bpy.ops.td.create_material()
            return {'FINISHED'}

        elif setd.paint_mode == '2D':
            bpy.ops.td.canvas_setup_popup('INVOKE_DEFAULT')
            return {'FINISHED'}

                




class td_OT_canvas_setup_popup(bpy.types.Operator):
    bl_idname = "td.canvas_setup_popup"
    bl_label = "Canvas Setup"

    object_action: bpy.props.EnumProperty(
        name="Object",
        items=[
            ('HIDE', "Hide Object", "Hide the current object"),
            ('DELETE', "Delete Object", "Delete the current object")
        ],
        default='HIDE'
    )

    canvas_size: bpy.props.EnumProperty(
        name="Canvas Size",
        items=[
            ('H_1920', "Horizontal 1920 × 1080", ""),
            ('H_2048', "Horizontal 2048 × 1152", ""),
            ('H_4096', "Horizontal 4096 × 2304", ""),
            ('V_1080', "Vertical 1080 × 1920", ""),
            ('V_2048', "Vertical 1152 × 2048", ""),
            ('V_4096', "Vertical 2304 × 4096", ""),
            ('CUSTOM', "Custom Size", "")
        ],
        default='H_1920'
    )

    custom_width: bpy.props.IntProperty(name="Width", default=2048, min=64, max=8192)
    custom_height: bpy.props.IntProperty(name="Height", default=2048, min=64, max=8192)

    def invoke(setd, context, event):
        return context.window_manager.invoke_props_dialog(setd)

    def draw(setd, context):
        layout = setd.layout
        layout.label(text="2D Workflow Setup")

        layout.prop(setd, "object_action", expand=True)
        layout.separator()

        layout.label(text="Canvas Size")
        layout.prop(setd, "canvas_size")

        if setd.canvas_size == 'CUSTOM':
            col = layout.column()
            col.prop(setd, "custom_width")
            col.prop(setd, "custom_height")

    def execute(setd, context):
        obj = context.object


        if setd.object_action == 'HIDE':
            obj.hide_set(True)
            obj.hide_render = True
        else:
            bpy.data.objects.remove(obj, do_unlink=True)


        sizes = {
            'H_1920': (1920, 1080),
            'H_2048': (2048, 1152),
            'H_4096': (4096, 2304),
            'V_1080': (1080, 1920),
            'V_2048': (1152, 2048),
            'V_4096': (2304, 4096),
        }

        if setd.canvas_size == 'CUSTOM':
            w, h = setd.custom_width, setd.custom_height
        else:
            w, h = sizes[setd.canvas_size]

        

        bpy.ops.mesh.primitive_plane_add(size=1)
        plane = context.object
        plane.name = "td_Canvas"

        plane.rotation_euler = (1.5708, 0, 0)  


        plane.scale.x = (w / 100) / 2  
        plane.scale.y = (h / 100) / 2  


        cam = context.scene.camera
        if not cam:
            bpy.ops.object.camera_add(location=(0, -10, 0))
            cam = context.active_object
            context.scene.camera = cam


        is_vertical = h > w

        if is_vertical:

            dist = (h / 100)      
        else:

            dist = (w / 100) / 2  

        cam.location = (0, -dist, 0)  
        cam.rotation_euler = (1.5708, 0, 0)  
        cam.data.lens = 35


        bpy.ops.td.create_material()


        for window in context.window_manager.windows:
            screen = window.screen
            for area in screen.areas:
                if area.type == 'VIEW_3D':
                    for region in area.regions:
                        if region.type == 'WINDOW':
                            with context.temp_override(area=area, region=region):
                                bpy.ops.view3d.view_camera()
                            break
                    break  

        setd.report({'INFO'}, "Canvas Mode initialized.")
        return {'FINISHED'}











class td_OT_create_material(bpy.types.Operator):
    bl_idname = "td.create_material"
    bl_label = "Create ToKoDraw Material"
    bl_description = "Create a new ToKoDraw material and initialize the layer system"

    def execute(setd, context):
        obj = context.object
        if not obj:
            setd.report({'ERROR'}, "No object selected")
            return {'CANCELLED'}

        scene = context.scene
        



        mat = create_ToKoDraw_material(obj)


        if "td_layer_count" not in mat:
            mat["td_layer_count"] = 2


        if mat.name not in obj.data.materials:
            obj.data.materials.append(mat)



        bpy.ops.object.mode_set(mode='TEXTURE_PAINT')


        for area in bpy.context.screen.areas:
            if area.type == 'VIEW_3D':
                for space in area.spaces:
                    if space.type == 'VIEW_3D':
                        space.shading.type = 'MATERIAL'


        td_id = mat.get("td_id")
        if not td_id:
            setd.report({'ERROR'}, "Material has no td_id")
            return {'CANCELLED'}





        layers = get_layer_chain(mat)
        if not layers:
            setd.report({'ERROR'}, "ToKoDraw material has no layers")
            return {'CANCELLED'}


        layer0_group = layers[0]


        layer0_group.location = (-1100, 200 - (1 * 200))


        layer0_image = None
        tex_node = layer0_group.node_tree.nodes.get("Texture")

        if tex_node:
            uid0 = layer0_group.get("td_uid")
            if uid0:
                layer0_image = next(
                    (img for img in bpy.data.images if img.get("td_uid") == uid0),
                    None
                )
                tex_node.image = layer0_image






        layers = get_layer_chain(mat)
        if len(layers) < 2:
            setd.report({'ERROR'}, "ToKoDraw material missing Layer 1")
            return {'CANCELLED'}


        layer1_group = layers[1]


        layer1_group.location = (-1100, 200 - (2 * 200))


        tex_node = layer1_group.node_tree.nodes.get("Texture")
        if tex_node:
            uid1 = layer1_group.get("td_uid")
            if uid1:
                img = next(
                    (img for img in bpy.data.images if img.get("td_uid") == uid1),
                    None
                )
                tex_node.image = img






        nbadds = get_nbadd_chain(mat)
        if not nbadds:
            setd.report({'ERROR'}, "ToKoDraw material has no NBAdd nodes")
            return {'CANCELLED'}


        nbadd1 = nbadds[0]


        nbadd1.location = (-900, 200 - (2 * 200))







        layers = get_layer_chain(mat)
        if not layers:
            setd.report({'ERROR'}, "ToKoDraw material has no layers")
            return {'CANCELLED'}


        layer0_group = layers[0]
        layer0_group.label = "Canvas"


        layer1_group = layers[1]


        tex_node = layer1_group.node_tree.nodes.get("Texture")
        if tex_node and tex_node.image:
            scene.tool_settings.image_paint.canvas = tex_node.image


        scene.td_active_layer = layer1_group.node_tree.name
        scene.td_active_layer_index = 1
        scene.td_active_layer_uid = layer1_group.get("td_uid")
        scene.td_active_opacity = 1.0


        for n in mat.node_tree.nodes:
            n.select = False

        layer1_group.select = True
        mat.node_tree.nodes.active = layer1_group






        for area in bpy.context.screen.areas:
            if area.type == 'PROPERTIES':
                for space in area.spaces:
                    if space.type == 'PROPERTIES':

                        space.context = 'TOOL'  
                break


        return {'FINISHED'}

    


        
