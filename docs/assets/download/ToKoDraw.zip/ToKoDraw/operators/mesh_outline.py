import bpy

def update_outline_thickness(setd, context):
    scene = setd  

    obj = context.object
    if not obj:
        return

    outline_name = f"{obj.name}_Outline"
    outline_obj = bpy.data.objects.get(outline_name)
    if not outline_obj:
        return

    solid = outline_obj.modifiers.get("td_OutlineSolidify")
    if not solid:
        return


    solid.thickness = scene.td_outline_thickness




class td_OT_outline(bpy.types.Operator):
    bl_idname = "td.outline"
    bl_label = "Outline & Settings"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Add Outline and manage its settings."


    def execute(setd, context):
        obj = context.object
        outline_name = f"{obj.name}_Outline"


        if outline_name not in bpy.data.objects:
            bpy.ops.td.add_outline()


        bpy.ops.wm.call_panel(name="td_PT_outline_window")
        return {'FINISHED'}



class td_OT_add_outline(bpy.types.Operator):
    bl_idname = "td.add_outline"
    bl_label = "Add Outline"

    def execute(setd, context):

        obj = context.object
        if not obj or obj.type != 'MESH':
            setd.report({'WARNING'}, "Select a mesh.")
            return {'CANCELLED'}


        outline_name = f"{obj.name}_Outline"
        if outline_name in bpy.data.objects:
            setd.report({'INFO'}, "Outline déjà créé pour cet objet.")


        bpy.ops.object.mode_set(mode='OBJECT')


        context.view_layer.objects.active = obj
        obj.select_set(True)


        bpy.ops.object.mode_set(mode='EDIT')


        bpy.ops.mesh.select_all(action='SELECT')


        bpy.ops.mesh.remove_doubles(threshold=0.0001)


        bpy.ops.mesh.fill_holes()


        bpy.ops.object.mode_set(mode='OBJECT')


        scene = context.scene


        col_name = f"Outline - {obj.name}"
        col_outline = bpy.data.collections.get(col_name)

        if not col_outline:
            col_outline = bpy.data.collections.new(col_name)
            context.scene.collection.children.link(col_outline)


        outline_obj = obj.copy()
        outline_obj.data = obj.data.copy()
        outline_obj.name = f"{obj.name}_Outline"
       

        for coll in outline_obj.users_collection:
            coll.objects.unlink(outline_obj)


        col_outline.objects.link(outline_obj)


        mat = bpy.data.materials.new(name="td_OutlineMat")
        mat.use_nodes = True

        nodes = mat.node_tree.nodes
        links = mat.node_tree.links


        for n in nodes:
            nodes.remove(n)


        bsdf = nodes.new("ShaderNodeBsdfPrincipled")
        bsdf.inputs["Base Color"].default_value = (0, 0, 0, 1)
        bsdf.inputs["Roughness"].default_value = 1.0


        output = nodes.new("ShaderNodeOutputMaterial")
        links.new(bsdf.outputs["BSDF"], output.inputs["Surface"])


        outline_obj.data.materials.clear()
        outline_obj.data.materials.append(mat)

        mat.blend_method = 'OPAQUE'
        mat.use_backface_culling = True


        solid = outline_obj.modifiers.new(name="td_OutlineSolidify", type='SOLIDIFY')
      
        solid.thickness = 0.009    
        solid.offset = 0.5
    
        solid.use_quality_normals = True

        solid.use_flip_normals = True



        solid = outline_obj.modifiers.get("td_OutlineSolidify")
        if solid:


            for constraint in outline_obj.constraints:
                outline_obj.constraints.remove(constraint)


            copy_transforms = outline_obj.constraints.new(type='COPY_TRANSFORMS')
            copy_transforms.target = obj


            bpy.ops.object.select_all(action='DESELECT')
            obj.select_set(True)
            context.view_layer.objects.active = obj



        context.scene.td_outline_thickness = solid.thickness


        outline_obj.hide_select = True


        bpy.ops.object.mode_set(mode='TEXTURE_PAINT')


        return {'FINISHED'}





class td_PT_outline_window(bpy.types.Panel):
    bl_idname = "td_PT_outline_window"
    bl_label = "Outline Settings"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
 

    def draw(setd, context):
        layout = setd.layout
        scene = context.scene
        obj = context.object

        outline_name = f"{obj.name}_Outline"
        outline_obj = bpy.data.objects.get(outline_name)

        layout.label(text="Outline Mesh Settings")

        if not outline_obj:
            layout.label(text="Outline object missing.", icon="ERROR")
            return


        if "td_OutlineSolidify" in outline_obj.modifiers:
            solid = outline_obj.modifiers["td_OutlineSolidify"]

            layout.prop(scene, "td_outline_thickness", text="Thickness", slider=True)
            layout.prop(solid, "offset", text="Offset")
            layout.prop(solid, "use_flip_normals", text="Flip Normals")


        mat = outline_obj.active_material
        if mat and mat.node_tree:
            bsdf = mat.node_tree.nodes.get("Principled BSDF")
            if bsdf:
                layout.prop(bsdf.inputs["Alpha"], "default_value", text="Alpha")


        layout.prop(scene, "td_outline_hidden", text="Hide Outline")


        if outline_obj:
            if scene.td_outline_hidden:
                outline_obj.select_set(False)
                if context.view_layer.objects.active == outline_obj:
                    context.view_layer.objects.active = None

            outline_obj.hide_set(scene.td_outline_hidden)


        row = layout.row()
        row.operator("td.delete_outline", text="Delete Outline", icon="TRASH")






class td_OT_delete_outline(bpy.types.Operator):
    bl_idname = "td.delete_outline"
    bl_label = "Delete Outline"

    def execute(setd, context):

        obj = context.object
        if not obj:
            return {'CANCELLED'}

        outline_name = f"{obj.name}_Outline"
        outline_obj = bpy.data.objects.get(outline_name)


        if outline_obj:


            for c in outline_obj.constraints:
                outline_obj.constraints.remove(c)


            bpy.data.objects.remove(outline_obj, do_unlink=True)


        obj.td_show_outline_settings = False
        context.scene.td_outline_hidden = False



        return {'FINISHED'}



