import bpy
import os
import numpy as np

from bpy.props import StringProperty
from bpy.props import BoolProperty
from ..core.material_utils import get_active_td_material


from ..core.layer_utils import (
    get_active_layer_group,
    get_active_layer_tex_node,
    get_active_layer_image,
    get_tex_node_from_layer, 
    get_hardalpha_node,
   
)
from ..core.layer_chain_utils import (
    get_nbadd_for_layer,
    get_layer_chain,
)

from .remove_layer import remove_layer_at_index

class td_OT_open_layer_settings(bpy.types.Operator):

    bl_idname = "td.open_layer_settings"
    bl_label = "Toggle Menu"

    key: StringProperty()

    def execute(setd, context):
        scene = context.scene


        scene[setd.key] = not scene.get(setd.key, False)

        return {'FINISHED'}






class td_OT_toggle_layer_visibility(bpy.types.Operator):
    bl_idname = "td.toggle_layer_visibility"
    bl_label = "Hide / Show Layer"
    bl_description = "Toggle visibility of this layer"

    layer_index: bpy.props.IntProperty()

    layer_name: bpy.props.StringProperty()

    def execute(setd, context):
        

        mat = context.object.active_material
        layers = get_layer_chain(mat)

        layer_node = next((l for l in layers if l.name == setd.layer_name), None)

        if not layer_node:
            setd.report({'ERROR'}, f"Layer '{setd.layer_name}' introuvable.")
            return {'CANCELLED'}


        tex_node = get_tex_node_from_layer(layer_node)

        if not tex_node:
            setd.report({'WARNING'}, f"Aucun TEX_IMAGE trouvé dans '{setd.layer_name}'")
            return {'CANCELLED'}


        tex_node.mute = not tex_node.mute

        return {'FINISHED'}








class td_OT_toggle_layer_solo(bpy.types.Operator):
    bl_idname = "td.toggle_layer_solo"
    bl_label = "Solo Layer"
    bl_description = "Solo this layer (mute all others)"

    layer_name: bpy.props.StringProperty()

    def execute(setd, context):
    

        mat = context.object.active_material
        layers = get_layer_chain(mat)


        layer_node = next(
            (l for l in layers if l.name == setd.layer_name),
            None
        )
        if not layer_node:
            setd.report({'ERROR'}, f"Layer '{setd.layer_name}' introuvable.")
            return {'CANCELLED'}


        tex_clicked = get_tex_node_from_layer(layer_node)
        if not tex_clicked:
            setd.report({'WARNING'}, "Layer sans TEX_IMAGE interne")
            return {'CANCELLED'}


        is_solo = (
            not tex_clicked.mute and
            all(
                (get_tex_node_from_layer(l).mute if get_tex_node_from_layer(l) else True)
                for l in layers if l != layer_node
            )
        )

        if is_solo:

            for l in layers:
                tex = get_tex_node_from_layer(l)
                if tex:
                    tex.mute = False
        else:

            for l in layers:
                tex = get_tex_node_from_layer(l)
                if tex:
                    tex.mute = (l != layer_node)

        return {'FINISHED'}







class td_OT_toggle_lock_alpha(bpy.types.Operator):
    bl_idname = "td.toggle_lock_alpha"
    bl_label = "Toggle Lock Alpha"
    bl_description = "Prevent painting from affecting the alpha channel of this layer"

    layer_name: bpy.props.StringProperty()

    def execute(setd, context):


        mat = getattr(context.object, "active_material", None)
        if not mat or not mat.node_tree:
            return {'CANCELLED'}


        layers = get_layer_chain(mat)
        target = next((l for l in layers if l.name == setd.layer_name), None)
        if not target or not target.node_tree:
            return {'CANCELLED'}


        current = target.node_tree.get("td_lock_alpha", False)


        new_state = not current
        target.node_tree["td_lock_alpha"] = new_state


        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.mode_set(mode='TEXTURE_PAINT')



        prefs = context.preferences.addons["ToKoDraw"].preferences


        if new_state and prefs.show_lock_alpha_warning:
            bpy.ops.td.lock_alpha_warning('INVOKE_DEFAULT')


        bpy.context.tool_settings.image_paint.detect_data()

        return {'FINISHED'}




class td_OT_lock_alpha_warning(bpy.types.Operator):
    bl_idname = "td.lock_alpha_warning"
    bl_label = "Lock Alpha Information"

    dont_show_again: bpy.props.BoolProperty(name="Don't show again")

    def invoke(setd, context, event):
        return context.window_manager.invoke_props_dialog(setd)

    def draw(setd, context):
        layout = setd.layout
        layout.label(text="Blender applies Lock Alpha after the next viewport click.")
        layout.label(text="Changing brushes may temporarily re-enable alpha.")
        layout.label(text="Click once in an empty viewport after switching brushes.")
        layout.prop(setd, "dont_show_again")

    def execute(setd, context):
        prefs = context.preferences.addons.get("ToKoDraw")
        if prefs:
            prefs = prefs.preferences
            if setd.dont_show_again:
                prefs.show_lock_alpha_warning = False
        return {'FINISHED'}







class td_OT_toggle_lock_layer(bpy.types.Operator):
    bl_idname = "td.toggle_lock_layer"
    bl_label = "Toggle Lock Layer"
    bl_description = "Lock this layer to prevent any painting on it"

    layer_name: bpy.props.StringProperty()

    def execute(setd, context):


        obj = context.object
        if not obj:
            return {'CANCELLED'}

        mat = obj.active_material
        if not mat or not mat.node_tree:
            return {'CANCELLED'}


        layers = get_layer_chain(mat)
        if not layers:
            return {'CANCELLED'}


        target = next((l for l in layers if l.name == setd.layer_name), None)
        if not target or not target.node_tree:
            return {'CANCELLED'}


        current = target.node_tree.get("td_lock_layer", False)
        new_state = not current
        target.node_tree["td_lock_layer"] = new_state


        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.mode_set(mode='TEXTURE_PAINT')


        addon = context.preferences.addons.get("ToKoDraw")
        if addon:
            prefs = addon.preferences

            if new_state and prefs.show_lock_layer_warning:
                bpy.ops.td.lock_layer_warning('INVOKE_DEFAULT')


        bpy.context.tool_settings.image_paint.detect_data()


        return {'FINISHED'}




class td_OT_lock_layer_warning(bpy.types.Operator):
    bl_idname = "td.lock_layer_warning"
    bl_label = "Lock Layer Information"

    dont_show_again: bpy.props.BoolProperty(name="Don't show again")

    def invoke(setd, context, event):
        return context.window_manager.invoke_props_dialog(setd)

    def draw(setd, context):
        layout = setd.layout
        layout.label(text="Blender may take a moment to fully apply the lock.")
        layout.label(text="For best results, select another layer right after locking.")
        layout.label(text="Or click once in an empty area of the viewport.")
        layout.prop(setd, "dont_show_again")

    def execute(setd, context):


        addon = context.preferences.addons.get("ToKoDraw")
        if addon:
            prefs = addon.preferences
            if setd.dont_show_again:
                prefs.show_lock_layer_warning = False

        return {'FINISHED'}






#-------------------------------------------
# Op Duplicate Layer
#-------------------------------------------

class td_OT_duplicate_layer(bpy.types.Operator):
    bl_idname = "td.duplicate_layer"
    bl_label = "Duplicate Layer"
    bl_description = "Duplicate this layer and its image"

    layer_name: bpy.props.StringProperty()

    def execute(setd, context):

        obj = context.object
        if not obj or obj.type != 'MESH':
            return {'CANCELLED'}

        mat = obj.active_material
        if not mat or not mat.node_tree:
            return {'CANCELLED'}

        td_tree = mat.node_tree

        
        src_layer = next(
            (n for n in td_tree.nodes if n.get("td_uid") == setd.layer_name),
            None
        )
        if not src_layer:
            return {'CANCELLED'}
        

       
        src_tex = next(
            (n for n in src_layer.node_tree.nodes if n.type == "TEX_IMAGE"),
            None
        )
        if not src_tex or not src_tex.image:
            return {'CANCELLED'}

        source_img = src_tex.image
        source_size = source_img.size[0]  

        src_uid = src_layer.get("td_uid")

        
        bpy.ops.td.add_layer(
            size=source_size,
            duplicate_from=src_uid,
            duplicate_mode=True,
        )

        return {'FINISHED'}


#-------------------------------------------
# Op Duplicate Post Process
#-------------------------------------------

class td_OT_post_duplicate(bpy.types.Operator):
    bl_idname = "td.post_duplicate"
    bl_label = "Post Duplicate"
    bl_description = "Copy pixels from source layer into the new layer image"

    new_layer_uid: bpy.props.StringProperty()
    src_layer_uid: bpy.props.StringProperty()

    def execute(setd, context):

        obj = context.object
        mat = obj.active_material
        td_tree = mat.node_tree

        layers = get_layer_chain(mat)

        # Source
        src_layer = next((l for l in layers if l.get("td_uid") == setd.src_layer_uid), None)
        src_tex = next((n for n in src_layer.node_tree.nodes if n.type == "TEX_IMAGE"), None)
        src_img = src_tex.image

        # New
        new_layer = next((l for l in layers if l.get("td_uid") == setd.new_layer_uid), None)
        new_tex = next((n for n in new_layer.node_tree.nodes if n.type == "TEX_IMAGE"), None)
        dup_img = new_tex.image

        # --- Rename layer label ---
        src_label = src_layer.label or src_layer.name
        new_layer.label = f"{src_label} - dup"

        # --- Rename image ---
        dup_img.name = src_img.name + "_dup"

        
        # Sync source
        src_img.update()
        src_img.gl_touch()
        src_img.update()

        w, h = src_img.size

        # Lire pixels en float32 (propre)
        buf = np.empty(w * h * 4, dtype=np.float32)
        src_img.pixels.foreach_get(buf)

        rgba = buf.reshape(-1, 4)
        alpha = rgba[:, 3]
        rgb = rgba[:, :3]

        # Le layer source est-il déjà traité ?
        is_processed = src_img.get("td_is_processed", False)

        # Anti-halo straight
        mask = alpha < 0.02
        rgb[mask] = 0.0

        # Correction douce uniquement si le layer source n'est PAS traité
        if not is_processed:
            rgb[~mask] *= alpha[~mask, None]

        # ---------------------------------------------------------


        # Écrire pixels (propre)
        dup_img.pixels.foreach_set(buf)

        # Sync destination
        dup_img.update()
        dup_img.gl_touch()
        dup_img.update()

        dup_img.pack()
        dup_img["td_is_processed"] = True



        # Update canvas
        context.scene.tool_settings.image_paint.canvas = dup_img

        if context.area:
            context.area.tag_redraw()

        return {'FINISHED'}





class td_OT_rename_layer(bpy.types.Operator):
    bl_idname = "td.rename_layer"
    bl_label = "Rename Layer (UI only)"
    bl_description = "Rename this layer in the ToKoDraw interface"

    layer_name: bpy.props.StringProperty()
    new_name: bpy.props.StringProperty(name="New Layer Name")

    def invoke(setd, context, event):
        return context.window_manager.invoke_props_dialog(setd)

    def execute(setd, context):


        obj = context.object
        if not obj:
            return {'CANCELLED'}

        mat = obj.active_material
        if not mat or not mat.node_tree:
            return {'CANCELLED'}


        td_tree = mat.node_tree
            

        layer_uid = setd.layer_name
        layer_node = next((n for n in td_tree.nodes if n.get("td_uid") == layer_uid), None)
        if not layer_node:
            return {'CANCELLED'}


        layer_node["td_ui_name"] = setd.new_name


        layer_node.label = setd.new_name


        if context.area:
            context.area.tag_redraw()


        return {'FINISHED'}






class td_OT_reset_popups(bpy.types.Operator):
    bl_idname = "td.reset_popups"
    bl_label = "Reset Popups"
    bl_description = "Re-enable all ToKoDraw warning popups"

    def execute(setd, context):
        prefs = context.preferences.addons["ToKoDraw"].preferences
        prefs.show_lock_layer_warning = True
        prefs.show_lock_alpha_warning = True

        setd.report({'INFO'}, "ToKoDraw popups have been re-enabled")
        return {'FINISHED'}








class td_OT_new_image(bpy.types.Operator):
    bl_idname = "td.new_image"
    bl_label = "New Image"

    layer_uid: bpy.props.StringProperty()


    name: bpy.props.StringProperty(name="Name", default="td_NewImage")
    width: bpy.props.IntProperty(name="Width", default=2048, min=1)
    height: bpy.props.IntProperty(name="Height", default=2048, min=1)

    generated_type: bpy.props.EnumProperty(
        name="Type",
        items=[
            ('BLANK', "Blank", ""),
            ('UV_GRID', "UV Grid", ""),
            ('COLOR_GRID', "Color Grid", "")
        ],
        default='BLANK'
    )

    color: bpy.props.FloatVectorProperty(
        name="Color",
        subtype='COLOR',
        size=4,
        default=(1.0, 1.0, 1.0, 0.0)  
    )

    float_buffer: bpy.props.BoolProperty(
        name="Float Buffer",
        default=False
    )

    def execute(setd, context):
        obj = context.object
        if not obj:
            return {'CANCELLED'}

        mat = obj.active_material
        if not mat or not mat.node_tree:
            return {'CANCELLED'}


        layer_node = next(
            (n for n in mat.node_tree.nodes if n.get("td_uid") == setd.layer_uid),
            None
        )
        if not layer_node:
            setd.report({'ERROR'}, "Layer introuvable.")
            return {'CANCELLED'}

        tex_node = get_tex_node_from_layer(layer_node)
        if not tex_node:
            setd.report({'ERROR'}, "No TEX_IMAGE found.")
            return {'CANCELLED'}


        img = bpy.data.images.new(
            name=setd.name,
            width=setd.width,
            height=setd.height,
            alpha=True,
            float_buffer=setd.float_buffer
        )


        img.generated_type = setd.generated_type


        if setd.generated_type == 'BLANK':
            img.generated_color = setd.color

        img["td_uid"] = setd.layer_uid


        tex_node.image = img

        return {'FINISHED'}

    def invoke(setd, context, event):
        return context.window_manager.invoke_props_dialog(setd)




class td_OT_import_image(bpy.types.Operator):
    bl_idname = "td.import_image"
    bl_label = "Import Image / Sequence"

    layer_uid: bpy.props.StringProperty()
    directory: bpy.props.StringProperty(subtype="DIR_PATH")
    files: bpy.props.CollectionProperty(type=bpy.types.OperatorFileListElement)

    filter_glob: bpy.props.StringProperty(default="*.png;*.jpg;*.jpeg;*.tga;*.tif;*.bmp")
    filter_image: bpy.props.BoolProperty(default=True)
    filemode: bpy.props.IntProperty(default=9)  

    def execute(setd, context):
        obj = context.object
        if not obj:
            return {'CANCELLED'}

        mat = obj.active_material
        if not mat or not mat.node_tree:
            return {'CANCELLED'}


        layer_node = next(
            (n for n in mat.node_tree.nodes if n.get("td_uid") == setd.layer_uid),
            None
        )
        if not layer_node:
            setd.report({'ERROR'}, f"Layer '{setd.layer_uid}' introuvable.")
            return {'CANCELLED'}

        tex_node = get_tex_node_from_layer(layer_node)
        if not tex_node:
            setd.report({'ERROR'}, "No TEX_IMAGE found in this layer.")
            return {'CANCELLED'}


        filepaths = [os.path.join(setd.directory, f.name) for f in setd.files]

        if len(filepaths) == 1:

            img = bpy.data.images.load(filepaths[0])
            img.source = 'FILE'
            tex_node.image = img

        else:


            img = bpy.data.images.load(filepaths[0])
            img.source = 'SEQUENCE'
            img.filepath = filepaths[0]


            tex_node.image_user.frame_duration = len(filepaths)
            tex_node.image_user.use_auto_refresh = True

            tex_node.image = img

        return {'FINISHED'}

    def invoke(setd, context, event):
        context.window_manager.fileselect_add(setd)
        return {'RUNNING_MODAL'}





class td_OT_remove_image(bpy.types.Operator):
    bl_idname = "td.remove_image"
    bl_label = "Remove Image"

    layer_uid: bpy.props.StringProperty()
    confirm: bpy.props.BoolProperty(default=False)

    def execute(setd, context):

        obj = context.object
        if not obj:
            return {'CANCELLED'}

        mat = obj.active_material
        if not mat or not mat.node_tree:
            return {'CANCELLED'}


        layer_node = next(
            (n for n in mat.node_tree.nodes if n.get("td_uid") == setd.layer_uid),
            None
        )
        if not layer_node:
            setd.report({'ERROR'}, f"Layer '{setd.layer_uid}' not found.")
            return {'CANCELLED'}

        tex_node = get_tex_node_from_layer(layer_node)
        if not tex_node:
            setd.report({'ERROR'}, "No TEX_IMAGE found in this layer.")
            return {'CANCELLED'}

        img = tex_node.image
        if not img:
            setd.report({'INFO'}, "No image assigned.")
            return {'FINISHED'}


        tex_node.image = None


        still_used_elsewhere = any(
            n.type == 'TEX_IMAGE' and n.image == img
            for mat in bpy.data.materials
            for n in (mat.node_tree.nodes if mat.node_tree else [])
        )


        if still_used_elsewhere and not setd.confirm:
            return context.window_manager.invoke_props_dialog(setd)


        if not still_used_elsewhere or setd.confirm:
            bpy.data.images.remove(img)

        return {'FINISHED'}

    def draw(setd, context):
        layout = setd.layout
        layout.label(text="This image is used in other layers/materials.")
        layout.label(text="Do you really want to delete it?")
        layout.prop(setd, "confirm", text="Yes, delete")




