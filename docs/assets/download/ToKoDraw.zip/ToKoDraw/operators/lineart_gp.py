import bpy

class td_OT_lineart(bpy.types.Operator):
    bl_idname = "td.lineart"
    bl_label = "LineArt & Settings"
    bl_description = "Add Line Art and manage its settings."

    def execute(setd, context):
        obj = context.object
        lineart_name = f"{obj.name}_LineArt"

        if lineart_name not in bpy.data.objects:
            bpy.ops.td.add_lineart()

        bpy.ops.wm.call_panel(name="td_PT_lineart_window")
        return {'FINISHED'}




class td_OT_add_lineart(bpy.types.Operator):
    bl_idname = "td.add_lineart"
    bl_label = "Add Line Art"
    bl_options = {"REGISTER", "UNDO"}
    

    def execute(setd, context):
        mesh = context.active_object
        if not mesh or mesh.type != 'MESH':
            setd.report({'WARNING'}, "Select a mesh first")
            return {'CANCELLED'}

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')


        bpy.ops.object.grease_pencil_add(type="EMPTY", location=mesh.location)
        gp_obj = context.active_object


        gp_obj.name = f"{mesh.name}_LineArt"
        gp_obj.data.name = f"{mesh.name}_LineArtdata"



        if not gp_obj.data.layers:
            layer = gp_obj.data.layers.new(name="Lines", set_active=True)
        else:
            layer = gp_obj.data.layers.active
            layer.name = "Lines"


        mat_name = "td_LineArt_Black"
        mat = bpy.data.materials.get(mat_name)
        if not mat:
            mat = bpy.data.materials.new(mat_name)
            mat.use_nodes = True

            nt = mat.node_tree
            bsdf = nt.nodes.get("Principled BSDF")
            if bsdf:
                bsdf.inputs["Base Color"].default_value = (0.0, 0.0, 0.0, 1.0)

            bpy.data.materials.create_gpencil_data(mat)
            mat.grease_pencil.color = (0, 0, 0, 1)
            mat.grease_pencil.show_fill = False


        if mat.name not in gp_obj.data.materials:
            gp_obj.data.materials.append(mat)


        mod = gp_obj.modifiers.new("Line Art", 'LINEART')
        mod.source_type = 'OBJECT'
        mod.source_object = mesh


        mod.use_edge_mark = True
        mod.use_intersection = False
        mod.use_crease = True
        mod.use_back_face_culling = True
        mod.use_crease_on_smooth = True


        mod.target_layer = layer.name  
        mod.target_material = mat  
        mod.use_material = True  


        mod.radius = 0.02
        mod.opacity = 1.0
        mod.crease_threshold = 140  


        bpy.context.view_layer.update()
        gp_obj.update_tag()


        coll_name = f"td_LineArt_{mesh.name}"
        coll = bpy.data.collections.get(coll_name)


        if not coll:
            coll = bpy.data.collections.new(coll_name)
            context.scene.collection.children.link(coll)


        for c in gp_obj.users_collection:
            try:
                c.objects.unlink(gp_obj)
            except:
                pass  

        coll.objects.link(gp_obj)


        bpy.ops.object.select_all(action='DESELECT')
        mesh.select_set(True)
        context.view_layer.objects.active = mesh
        bpy.ops.object.mode_set(mode='TEXTURE_PAINT')



        context.object.td_show_lineart_settings = True


        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()

        
        setd.report({'INFO'}, "Line Art created")
        return {'FINISHED'}


class td_PT_lineart_window(bpy.types.Panel):
    bl_idname = "td_PT_lineart_window"
    bl_label = "Line Art Settings"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'

    def draw(setd, context):
        layout = setd.layout
        obj = context.object

        if not obj:
            return

        lineart_name = f"{obj.name}_LineArt"
        lineart_obj = bpy.data.objects.get(lineart_name)

        box = layout.box()
        box.label(text="Line Art Settings")


        if not lineart_obj:
            box.label(text="LineArt object missing.", icon="ERROR")
            return


        mod = lineart_obj.modifiers.get("Line Art")
        if not mod:
            box.label(text="Line Art modifier missing.", icon="ERROR")
            return


        box.label(text="Modifier")

        box.prop(mod, "source_object", text="Source Object")

        with context.temp_override(active_object=lineart_obj):
            box.prop(mod, "material", text="Material")

        box.prop(mod, "target_layer", text="Target Layer")
        box.prop(mod, "radius", text="Radius")
        box.prop(mod, "opacity", text="Opacity")
        box.prop(mod, "crease_threshold", text="Threshold", slider=True)
        box.prop(mod, "use_edge_mark", text="Edge Mark")
        box.prop(mod, "use_intersection", text="Intersection")
        box.prop(mod, "use_crease", text="Crease")

        box.separator()

        row = box.row()
        row.operator("td.delete_lineart", text="Delete Line Art", icon="TRASH")







class td_OT_delete_lineart(bpy.types.Operator):
    bl_idname = "td.delete_lineart"
    bl_label = "Delete Line Art"

    def execute(setd, context):
        obj = context.object
        if not obj:
            return {'CANCELLED'}



        la_name = f"td_LineArt_{obj.name}"
        la_obj = bpy.data.objects.get(la_name)


        coll_name = f"td_LineArt_{obj.name}"
        coll = bpy.data.collections.get(coll_name)


        if la_obj:

            mod = la_obj.modifiers.get("Line Art")
            if mod:
                la_obj.modifiers.remove(mod)


            bpy.data.objects.remove(la_obj, do_unlink=True)




        

        setd.report({'INFO'}, "Line Art supprimé (collection conservée).")
        return {'FINISHED'}



