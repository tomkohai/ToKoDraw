import bpy
from ..core.layer_chain_utils import get_layer_chain



class td_OT_layer_up(bpy.types.Operator):
    bl_idname = "td.layer_up"
    bl_label = "Layer Up"

    def execute(setd, context):
        scene = context.scene
        obj = context.object

        if not obj or obj.type != 'MESH':
            return {'CANCELLED'}

        mat = obj.active_material
        if not mat or not mat.node_tree:
            return {'CANCELLED'}


        layers = get_layer_chain(mat)
        layers = list(reversed(layers))

        index = scene.td_active_layer_index

        if index > 0:
            index -= 1

        layer = layers[index]


        scene.td_active_layer_index = index
        scene.td_active_layer = layer.node_tree.name
        scene.td_active_layer_uid = layer.get("td_uid")


        for n in mat.node_tree.nodes:
            n.select = False


        layer.select = True
        mat.node_tree.nodes.active = layer


        return {'FINISHED'}



class td_OT_layer_down(bpy.types.Operator):
    bl_idname = "td.layer_down"
    bl_label = "Layer Down"

    def execute(setd, context):
        scene = context.scene
        obj = context.object

        if not obj or obj.type != 'MESH':
            return {'CANCELLED'}

        mat = obj.active_material
        if not mat or not mat.node_tree:
            return {'CANCELLED'}


        layers = get_layer_chain(mat)
        layers = list(reversed(layers))

        index = scene.td_active_layer_index

        if index < len(layers) - 1:
            index += 1

        layer = layers[index]


        scene.td_active_layer_index = index
        scene.td_active_layer = layer.node_tree.name
        scene.td_active_layer_uid = layer.get("td_uid")


        for n in mat.node_tree.nodes:
            n.select = False


        layer.select = True
        mat.node_tree.nodes.active = layer

            
        return {'FINISHED'}
