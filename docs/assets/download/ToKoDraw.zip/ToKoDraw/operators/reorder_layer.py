import bpy
from bpy.types import Operator
from ..core.layer_chain_utils import (
    get_layer_chain,
    get_nbadd_chain,
    get_nbadd_for_layer,
    get_real_layer_nbadd_chain,
    swap_layer_positions,
)
from ..core.layer_utils import get_tex_node_from_layer
from ..properties.props import rebuild_merge_map




class td_OT_move_layer_up(bpy.types.Operator):
    bl_idname = "td.move_layer_up"
    bl_label = "Move Layer Up"

    def execute(setd, context):
        mat = context.object.active_material
        scene = context.scene

        layers, nbadds = get_real_layer_nbadd_chain(mat, master_name=None, debug=False)
        active_name = scene.td_active_layer
        index = layers.index(next(l for l in layers if l.name == active_name))


        if index == 0:
            return {'CANCELLED'}


        if index >= len(layers) - 1:
            return {'CANCELLED'}

        

        bpy.ops.td.reorder_layer(old=index, new=index+1)


        

        return {'FINISHED'}



class td_OT_move_layer_down(bpy.types.Operator):
    bl_idname = "td.move_layer_down"
    bl_label = "Move Layer Down"

    def execute(setd, context):
        mat = context.object.active_material
        scene = context.scene

        layers, nbadds = get_real_layer_nbadd_chain(mat, master_name=None, debug=False)
        active_name = scene.td_active_layer
        index = layers.index(next(l for l in layers if l.name == active_name))


        if index == 0:
            return {'CANCELLED'}


        if index <= 1:
            return {'CANCELLED'}

        

        bpy.ops.td.reorder_layer(old=index, new=index-1)


        

        return {'FINISHED'}






class td_OT_reorder_layer(Operator):
    bl_idname = "td.reorder_layer"
    bl_label = "Reorder Layer"

    old: bpy.props.IntProperty()
    new: bpy.props.IntProperty()

    def execute(setd, context):
        scene = context.scene
        obj = context.object
        mat = obj.active_material

        index_select_before = setd.old
        index_select_after = setd.new


        layers_before, nbadds_before = get_real_layer_nbadd_chain(mat, master_name=None, debug=True)



        Layer_Select = layers_before[index_select_before]
        NBAdd_Select = get_nbadd_for_layer(mat, Layer_Select)


        Layer_Swap = layers_before[index_select_after]
        NBAdd_Swap   = get_nbadd_for_layer(mat, Layer_Swap)



        swap_layer_positions(mat, index_select_before, index_select_after)



        mat.node_tree.update_tag()
        bpy.context.view_layer.update()
        td_tree = mat.node_tree
        td_nodes = td_tree.nodes
        td_links = td_tree.links


        td_nodes.active = Layer_Select



        new_layers, new_nbadds = get_real_layer_nbadd_chain(mat, master_name=None, debug=False)

        new_index_select = new_layers.index(Layer_Select)
        new_index_swap   = new_layers.index(Layer_Swap)

        
        layer_A = new_layers[new_index_select]
        nb_a = get_nbadd_for_layer(mat, layer_A)

        layer_B = new_layers[new_index_swap]
        nb_b = get_nbadd_for_layer(mat, layer_B)

        






        old = index_select_before
        new = index_select_after

        swap_up = new > old
        swap_down = new < old



        if new > old:





            if nb_a.inputs["Below_Color"].links:
                below_a = nb_a.inputs["Below_Color"].links[0].from_node
            else:
                below_a = new_layers[0]  

            above_b_links = nb_b.outputs["Out_Color"].links
            if above_b_links:
                above_b = above_b_links[0].to_node
            else:
                above_b = None  

        else:





            if nb_b.inputs["Below_Color"].links:
                below_b = nb_b.inputs["Below_Color"].links[0].from_node
            else:
                below_b = new_layers[0]  

            above_a_links = nb_a.outputs["Out_Color"].links
            if above_a_links:
                above_a = above_a_links[0].to_node
            else:
                above_a = None  



        for sock in ["Below_Color", "Below_Alpha"]:
            for link in list(nb_a.inputs[sock].links):
                td_links.remove(link)
            for link in list(nb_b.inputs[sock].links):
                td_links.remove(link)

        for out in nb_a.outputs:
            for link in list(out.links):
                td_links.remove(link)
        for out in nb_b.outputs:
            for link in list(out.links):
                td_links.remove(link)




        
        em = next((n for n in td_nodes if n.bl_idname == "ShaderNodeEmission"), None)
        bsdf = next((n for n in td_nodes if n.bl_idname == "ShaderNodeBsdfPrincipled"), None)
        mixshad = next((n for n in td_nodes if n.bl_idname == "ShaderNodeMixShader"), None)


                
        if new > old:





            td_links.new(below_a.outputs["Color"] if below_a == new_layers[0] else below_a.outputs["Out_Color"],
                        nb_b.inputs["Below_Color"])
            td_links.new(below_a.outputs["Alpha"] if below_a == new_layers[0] else below_a.outputs["Out_Alpha"],
                        nb_b.inputs["Below_Alpha"])


            td_links.new(nb_b.outputs["Out_Color"], nb_a.inputs["Below_Color"])
            td_links.new(nb_b.outputs["Out_Alpha"], nb_a.inputs["Below_Alpha"])


            if above_b and "NBAdd" in above_b.name:
                td_links.new(nb_a.outputs["Out_Color"], above_b.inputs["Below_Color"])
                td_links.new(nb_a.outputs["Out_Alpha"], above_b.inputs["Below_Alpha"])
            else:
                td_links.new(nb_a.outputs["Out_Color"], em.inputs["Color"])
                td_links.new(nb_a.outputs["Out_Alpha"], mixshad.inputs["Fac"])
                td_links.new(nb_a.outputs["Out_Color"], bsdf.inputs["Base Color"])
                td_links.new(nb_a.outputs["Out_Alpha"], bsdf.inputs["Alpha"])

        else:




            

            td_links.new(below_b.outputs["Color"] if below_b == new_layers[0] else below_b.outputs["Out_Color"],
                        nb_a.inputs["Below_Color"])
            td_links.new(below_b.outputs["Alpha"] if below_b == new_layers[0] else below_b.outputs["Out_Alpha"],
                        nb_a.inputs["Below_Alpha"])


            td_links.new(nb_a.outputs["Out_Color"], nb_b.inputs["Below_Color"])
            td_links.new(nb_a.outputs["Out_Alpha"], nb_b.inputs["Below_Alpha"])


            if above_a and "NBAdd" in above_a.name:
                td_links.new(nb_b.outputs["Out_Color"], above_a.inputs["Below_Color"])
                td_links.new(nb_b.outputs["Out_Alpha"], above_a.inputs["Below_Alpha"])
            else:
                td_links.new(nb_b.outputs["Out_Color"], em.inputs["Color"])
                td_links.new(nb_b.outputs["Out_Alpha"], mixshad.inputs["Fac"])
                td_links.new(nb_b.outputs["Out_Color"], bsdf.inputs["Base Color"])
                td_links.new(nb_b.outputs["Out_Alpha"], bsdf.inputs["Alpha"])

        
        mat.node_tree.update_tag()
        bpy.context.view_layer.update()

        new_layers, new_nbadds = get_real_layer_nbadd_chain(mat, master_name=None, debug=False)

        layers = get_layer_chain(mat)
        nbadds = get_nbadd_chain(mat)

        for i, layer in enumerate(layers):
            layer["td_index"] = i

        for i, nb in enumerate(nbadds, start=1):  
            nb["td_index"] = i

        for i, nb in enumerate(nbadds, start=1):
            base_label = nb.label if nb.label else nb.name
            nb.label = f"{base_label.split('[')[0].strip()} [{i}]"

        for layer in layers:
            tex = get_tex_node_from_layer(layer)
            if tex and tex.image:
                img = tex.image
                base_label = tex.label if tex.label else tex.name
                tex.label = f"{base_label.split('[')[0].strip()} [{layer['td_index']}]"


        active_uid = scene.td_active_layer_uid

        active_layer = next((l for l in layers if l.get("td_uid") == active_uid), None)
        if active_layer:
            scene.td_active_layer = active_layer.name
            scene.td_active_layer_index = layers.index(active_layer)

            tex = get_tex_node_from_layer(active_layer)
            if tex and tex.image:
                scene.tool_settings.image_paint.canvas = tex.image
         
        rebuild_merge_map(scene, layers)

        merge_map = scene.td_merge_map

        for item in merge_map:
            item.checked = False

        active_uid = scene.td_active_layer_uid
        active_item = merge_map.get(active_uid)
        if active_item:
            active_item.checked = True


        return {'FINISHED'}
