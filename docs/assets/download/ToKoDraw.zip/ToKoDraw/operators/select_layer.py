import bpy

from ..core.layer_utils import (
    get_active_layer_image,
)

from ..core.layer_chain_utils import get_layer_chain

class td_OT_select_layer(bpy.types.Operator):
    bl_idname = "td.select_layer"
    bl_label = "Select Layer"
    bl_description = "Select this layer"

    layer_name: bpy.props.StringProperty()
    layer_uid: bpy.props.StringProperty()


    def execute(setd, context):
        scene = context.scene
        obj = context.object
        mat = obj.active_material


        td_tree = mat.node_tree
        td_nodes = td_tree.nodes
            

        layer_group = None
        for n in td_nodes:
            if (
                n.type == 'GROUP'
                and n.node_tree
                and n.node_tree.name == setd.layer_name
            ):
                layer_group = n
                break

        if not layer_group:
            setd.report({'ERROR'}, f"Layer {setd.layer_name} not found")
            return {'CANCELLED'}


        scene.td_active_layer = setd.layer_name
        scene.td_active_layer_uid = setd.layer_uid


        merge_map = scene.td_merge_map


        for item in merge_map:
            item.checked = False


        merge_item = merge_map.get(setd.layer_uid)
        if merge_item:
            merge_item.checked = True



        img = get_active_layer_image(context)


        if img:
            scene.tool_settings.image_paint.canvas = img


        layers = get_layer_chain(mat)


        logical_index = 0
        for i, n in enumerate(layers):
            if n.node_tree.name == setd.layer_name:
                logical_index = i
                break


        scene.td_active_layer_index = logical_index


        scene.td_active_opacity = layer_group.inputs["Opacity"].default_value


        td_nodes.active = layer_group






        for area in bpy.context.screen.areas:
            if area.type == 'PROPERTIES':
                for space in area.spaces:
                    if space.type == 'PROPERTIES':

                        space.context = 'TOOL'  
                break


        


        return {'FINISHED'}


