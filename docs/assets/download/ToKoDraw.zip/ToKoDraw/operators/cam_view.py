import bpy


class td_OT_set_camera_view(bpy.types.Operator):
    bl_idname = "td.set_camera_view"
    bl_label = "Set Camera View"
    bl_description = "Position the camera to view the Line Art and switch to camera view."


    def execute(setd, context):


        if context.scene.td_camview:
            context.scene.td_camview = False
            


            for window in context.window_manager.windows:
                screen = window.screen
                for area in screen.areas:
                    if area.type == 'VIEW_3D':
                        region = next((r for r in area.regions if r.type == 'WINDOW'), None)
                        if region:
                            with context.temp_override(area=area, region=region):

                                area.spaces.active.region_3d.view_perspective = 'PERSP'
                                cam = context.scene.camera
                                if cam:
                                    cam.hide_viewport = True
            return {'FINISHED'}

        else:
            context.scene.td_camview = True


            if not context.scene.td_obj_transform_panel:
                context.scene.td_obj_transform_panel = True

      


        current_mode = context.mode
        original_obj = context.object  

        if not original_obj or original_obj.type != 'MESH':
            setd.report({'ERROR'}, "No valid mesh selected")
            return {'CANCELLED'}


        if current_mode == "PAINT_TEXTURE":
            current_mode = "TEXTURE_PAINT"


        if current_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')


        import mathutils
        world_bbox = [original_obj.matrix_world @ mathutils.Vector(corner) for corner in original_obj.bound_box]

        xs = [v.x for v in world_bbox]
        ys = [v.y for v in world_bbox]
        zs = [v.z for v in world_bbox]

        width = max(xs) - min(xs)
        height = max(zs) - min(zs)
        depth = max(ys) - min(ys)


        bbox_center = sum(world_bbox, mathutils.Vector()) / 8



        diagonal = mathutils.Vector((width, depth, height)).length
        dist = diagonal * 1.5  



        cam = context.scene.camera
        if not cam:

            bpy.ops.object.camera_add(location=(0, -10, 0))
            cam = context.active_object
            context.scene.camera = cam


        cam.location = (bbox_center.x, bbox_center.y - dist, bbox_center.z)
        cam.rotation_euler = (1.5708, 0, 0)  
        cam.data.lens = 35  


        for window in context.window_manager.windows:
            screen = window.screen
            for area in screen.areas:
                if area.type == 'VIEW_3D':
                    override = {
                        'window': window,
                        'screen': screen,
                        'area': area,
                        'region': next((r for r in area.regions if r.type == 'WINDOW'), None),
                        'scene': context.scene,
                    }
                    with context.temp_override(**override):
                        bpy.ops.view3d.view_camera()
                    break


        bpy.ops.object.select_all(action='DESELECT')
        original_obj.select_set(True)
        context.view_layer.objects.active = original_obj


        if current_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode=current_mode)

        return {'FINISHED'}





class td_OT_toggle_camview(bpy.types.Operator):
    bl_idname = "td.toggle_camview"
    bl_label = "Toggle CamView"
    bl_description = "Switch between Camera view and 3D view (Numpad 0)"

    def execute(setd, context):

        for window in context.window_manager.windows:
            screen = window.screen
            for area in screen.areas:
                if area.type == 'VIEW_3D':
                    region = next((r for r in area.regions if r.type == 'WINDOW'), None)
                    if region:

                        with context.temp_override(area=area, region=region):

                            if area.spaces.active.region_3d.view_perspective == 'CAMERA':

                                bpy.ops.view3d.view_orbit(angle=0.1)
                                area.spaces.active.region_3d.view_perspective = 'PERSP'
                                cam = context.scene.camera
                                if cam:
                                    cam.hide_viewport = True


                            else:

                                obj = context.object
                                cam = context.scene.camera

                                if obj and cam:
                                    import mathutils
                                    world_bbox = [obj.matrix_world @ mathutils.Vector(corner) for corner in obj.bound_box]
                                    bbox_center = sum(world_bbox, mathutils.Vector()) / 8


                                    if (cam.location - bbox_center).length > 0.001:
                                        bpy.ops.td.set_camera_view()
                                    else:
                                        bpy.ops.view3d.view_camera()
                                        area.spaces.active.region_3d.view_perspective = 'CAMERA'
                                else:
                                    bpy.ops.view3d.view_camera()
                                    area.spaces.active.region_3d.view_perspective = 'CAMERA'

                        return {'FINISHED'}
        return {'CANCELLED'}


class td_OT_obj_transform(bpy.types.Operator):
    bl_idname = "td.obj_transform"
    bl_label = "Set obj transfor panel"
    bl_description = "Open object transform panel for painting"

    def execute(setd, context):


        if context.scene.td_obj_transform_panel:
            context.scene.td_obj_transform_panel = False
            
        else:
            context.scene.td_obj_transform_panel = True
        
        return {'FINISHED'}


class td_OT_reset_transform(bpy.types.Operator):
    bl_idname = "td.reset_transform"
    bl_label = "Reset Transform"
    bl_description = "Réinitialise Location, Rotation et Scale de l'objet"

    def execute(setd, context):
        obj = context.object
        if not obj:
            return {'CANCELLED'}

        obj.location = (0.0, 0.0, 0.0)
        obj.rotation_euler = (0.0, 0.0, 0.0)
        obj.scale = (1.0, 1.0, 1.0)

        return {'FINISHED'}
