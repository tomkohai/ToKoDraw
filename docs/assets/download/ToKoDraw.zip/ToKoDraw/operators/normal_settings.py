import bpy
from bpy.types import Operator
from bpy.props import StringProperty
from bpy.props import BoolProperty

from ..core.layer_utils import get_tex_node_from_layer
from .render_switch import td_OT_render_switch





class td_OT_post_normalmap(bpy.types.Operator):
    bl_idname = "td.post_normalmap"
    bl_label = "Post Normal Map"
    bl_description = "Convert the newly created layer image into a Normal Map image"

    new_layer_uid: bpy.props.StringProperty()
    bit_depth: bpy.props.StringProperty(default="32")

    def execute(setd, context):
        obj = context.object
        mat = obj.active_material

        if not mat:
            setd.report({'ERROR'}, "No active material")
            return {'CANCELLED'}


        layer_node = next(
            (n for n in mat.node_tree.nodes if n.get("td_uid") == setd.new_layer_uid),
            None
        )

        if not layer_node:
            setd.report({'ERROR'}, "Layer not found")
            return {'CANCELLED'}


        tex_node = get_tex_node_from_layer(layer_node)
        if not tex_node or not tex_node.image:
            setd.report({'ERROR'}, "Texture node or image not found")
            return {'CANCELLED'}

        old_img = tex_node.image


        old_name = old_img.name
        old_uid = old_img.get("td_img_uid")
        width = old_img.size[0]
        height = old_img.size[1]


        bpy.data.images.remove(old_img)


        float_buffer = (setd.bit_depth == "32")

        new_img = bpy.data.images.new(
            name=old_name + " (Normal)",
            width=width,
            height=height,
            float_buffer=float_buffer,
            alpha=True
        )

        new_img.colorspace_settings.name = 'sRGB'
        new_img.update()
        new_img.pack()


        new_img.generated_color = (0.5, 0.5, 1.0, 1.0)


        if old_uid:
            new_img["td_img_uid"] = old_uid

        new_img["td_is_normal_img"] = True


        tex_node.image = new_img

    

       
        normal_tex_node = next(
            (n for n in mat.node_tree.nodes if n.get("td_is_normal") is True),
            None
        )

        if normal_tex_node:
            normal_tex_node.image = new_img




        output = next((n for n in mat.node_tree.nodes if n.bl_idname == "ShaderNodeOutputMaterial"), None)

        if output:
            socket = output.inputs.get("Surface")
            current = socket.links[0].from_node if socket and socket.links else None


            if not (current and current.bl_idname == "ShaderNodeBsdfPrincipled"):
                bpy.ops.td.render_switch()


        
        from ..core.normal_color_palette import create_all_normal_palettes
        create_all_normal_palettes()


        setd.report({'INFO'}, "Layer converted to Normal Map")
        return {'FINISHED'}













class td_OT_normal_import(bpy.types.Operator):
    bl_idname = "td.normal_import"
    bl_label = "Import normal map"
    bl_description = "Load a normal map image from disk"

    filepath: bpy.props.StringProperty(subtype="FILE_PATH")

    def invoke(setd, context, event):
        context.window_manager.fileselect_add(setd)
        return {'RUNNING_MODAL'}

    def execute(setd, context):
        obj = context.object
        mat = obj.active_material
        nt = mat.node_tree


        img_node = None
        for n in nt.nodes:
            if n.type == 'TEX_IMAGE' and n.get("td_is_normal"):
                img_node = n
                break

        if not img_node:
            setd.report({'ERROR'}, "Normal Texture introuvable.")
            return {'CANCELLED'}

        try:
            img = bpy.data.images.load(setd.filepath)
        except:
            setd.report({'ERROR'}, "Impossible de charger l'image.")
            return {'CANCELLED'}

        img_node.image = img
        return {'FINISHED'}




class td_OT_normal_rename(bpy.types.Operator):
    bl_idname = "td.normal_rename"
    bl_label = "Rename normal map"
    bl_description = "Rename the current normal map image"

    new_name: bpy.props.StringProperty(name="Nouveau nom")

    def invoke(setd, context, event):
        return context.window_manager.invoke_props_dialog(setd)

    def execute(setd, context):
        obj = context.object
        mat = obj.active_material
        nt = mat.node_tree

        img_node = None
        for n in nt.nodes:
            if n.type == 'TEX_IMAGE' and n.get("td_is_normal"):
                img_node = n
                break

        if not img_node or not img_node.image:
            setd.report({'ERROR'}, "Aucune image à renommer.")
            return {'CANCELLED'}

        img_node.image.name = setd.new_name
        return {'FINISHED'}



class td_OT_normal_remove(bpy.types.Operator):
    bl_idname = "td.normal_remove"
    bl_label = "Remove normal map"
    bl_description = "Remove the image from this normal texture node"

    confirm: bpy.props.BoolProperty(default=False)

    def execute(setd, context):
        obj = context.object
        mat = obj.active_material
        nt = mat.node_tree

        img_node = None
        for n in nt.nodes:
            if n.type == 'TEX_IMAGE' and n.get("td_is_normal"):
                img_node = n
                break

        if not img_node:
            setd.report({'ERROR'}, "Normal Texture introuvable.")
            return {'CANCELLED'}

        img = img_node.image
        if not img:
            setd.report({'INFO'}, "Aucune image assignée.")
            return {'FINISHED'}

        img_node.image = None

        still_used = any(
            n.type == 'TEX_IMAGE' and n.image == img
            for mat in bpy.data.materials
            for n in (mat.node_tree.nodes if mat.node_tree else [])
        )

        if still_used and not setd.confirm:
            return context.window_manager.invoke_props_dialog(setd)

        if not still_used or setd.confirm:
            bpy.data.images.remove(img)

        return {'FINISHED'}

    def draw(setd, context):
        layout = setd.layout
        layout.label(text="Cette image est utilisée ailleurs.")
        layout.prop(setd, "confirm", text="Oui, supprimer")
