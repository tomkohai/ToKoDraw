import bpy

from ..core.layer_chain_utils import get_layer_chain

def update_opacity(setd, context):
    mat = context.object.active_material
    layer_node = mat.node_tree.nodes.get(context.scene.td_active_layer)

    if layer_node and "Opacity" in layer_node.inputs:
        layer_node.inputs["Opacity"].default_value = context.scene.td_active_opacity





class td_OT_set_opacity(bpy.types.Operator):
    bl_idname = "td.set_opacity"
    bl_label = "Set Layer Opacity"

    value: bpy.props.FloatProperty()

    def execute(setd, context):
        scene = context.scene
        obj = context.object

        if not obj or obj.type != 'MESH':
            return {'CANCELLED'}

        mat = obj.active_material
        if not mat:
            return {'CANCELLED'}

        layer_node = mat.node_tree.nodes.get(scene.td_active_layer)



        layer_name = scene.td_active_layer
        try:
            index = scene.td_active_layer_index
            
        except:
            index = 0

        if "Opacity" in layer_node.inputs:
            layer_node.inputs["Opacity"].default_value = setd.value



        scene.td_active_opacity = setd.value

        return {'FINISHED'}


