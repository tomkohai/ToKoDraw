
import bpy

class td_OT_gp_create_object(bpy.types.Operator):
    bl_idname = "td.gp_create_object"
    bl_label = "Créer objet GP"
    bl_description = "Create GP Object"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(setd, context):


        for obj in bpy.data.objects:
            if obj.type == 'GREASEPENCIL' and obj.name.startswith("td_GP"):
                setd.report({'INFO'}, "A ToKoDraw GP object already exists.")
                bpy.ops.object.select_all(action='DESELECT')
                obj.select_set(True)
                context.view_layer.objects.active = obj
                return {'FINISHED'}


        gp_data = bpy.data.grease_pencils.new("td_GP_Data")
        gp_obj = bpy.data.objects.new("td_GP_Object", gp_data)


        context.collection.objects.link(gp_obj)


        bpy.ops.object.select_all(action='DESELECT')
        gp_obj.select_set(True)
        context.view_layer.objects.active = gp_obj


        gp_data.layers.new(name="Layer", set_active=True)


        bpy.ops.object.mode_set(mode='PAINT_GREASE_PENCIL')

        setd.report({'INFO'}, "Grease Pencil object created.")
        return {'FINISHED'}
