import bpy

from ..core.material_utils import get_active_td_material
from ..core.layer_chain_utils import (
    get_real_layer_nbadd_chain,
    get_layer_chain,
    get_nbadd_chain,
    get_nbadd_for_layer,
)
from ..core.layer_utils import get_tex_node_from_layer, get_active_layer_group
from ..properties.props import rebuild_merge_map
from .remove_layer import remove_layer_at_index
from .render_switch import td_OT_render_switch

import numpy as np

def get_layer_buffer_map(scene):
    store = scene.td_layer_buffers

    if not hasattr(store, "_buffers"):
        store._buffers = {}  

    return store._buffers



def blend_normal_np(bottom, top, out):
    a_b = bottom[:, 3]
    a_t = top[:, 3]

    out_a = a_t + a_b * (1 - a_t)

    mask = out_a > 1e-6

    out_rgb = np.zeros_like(bottom[:, :3])
    out_rgb[mask] = (
        top[mask, :3] * a_t[mask, None] +
        bottom[mask, :3] * a_b[mask, None] * (1 - a_t[mask, None])
    ) / out_a[mask, None]

    out[:, :3] = out_rgb
    out[:, 3] = out_a





def blend_multiply_np(bottom, top, out):
    a_b = bottom[:, 3]
    a_t = top[:, 3]

    out_a = a_t + a_b * (1 - a_t)

    mask = out_a > 1e-6

    out_rgb = np.zeros_like(bottom[:, :3])
    out_rgb[mask] = (
        (bottom[mask, :3] * top[mask, :3]) * a_t[mask, None] +
        bottom[mask, :3] * a_b[mask, None] * (1 - a_t[mask, None])
    ) / out_a[mask, None]

    out[:, :3] = out_rgb
    out[:, 3] = out_a



def blend_screen_np(bottom, top, out):
    a_b = bottom[:, 3]
    a_t = top[:, 3]

    out_a = a_t + a_b * (1 - a_t)

    mask = out_a > 1e-6

    out_rgb = np.zeros_like(bottom[:, :3])
    out_rgb[mask] = (
        (1 - (1 - bottom[mask, :3]) * (1 - top[mask, :3])) * a_t[mask, None] +
        bottom[mask, :3] * a_b[mask, None] * (1 - a_t[mask, None])
    ) / out_a[mask, None]

    out[:, :3] = out_rgb
    out[:, 3] = out_a


def blend_overlay_np(bottom, top, out):
    a_b = bottom[:, 3]
    a_t = top[:, 3]

    out_a = a_t + a_b * (1 - a_t)

    mask = out_a > 1e-6

    overlay = np.where(
        bottom[:, :3] < 0.5,
        2 * bottom[:, :3] * top[:, :3],
        1 - 2 * (1 - bottom[:, :3]) * (1 - top[:, :3])
    )

    out_rgb = np.zeros_like(bottom[:, :3])
    out_rgb[mask] = (
        overlay[mask] * a_t[mask, None] +
        bottom[mask, :3] * a_b[mask, None] * (1 - a_t[mask, None])
    ) / out_a[mask, None]

    out[:, :3] = out_rgb
    out[:, 3] = out_a




class td_OT_merge_visible_layers_info(bpy.types.Operator):
    bl_idname = "td.merge_visible_layers_info"
    bl_label = "Merge Visible Layers Info"
    bl_description = "Information popup for Merge Visible Layers"

    dont_show_again: bpy.props.BoolProperty(
        name="Don't show again",
        default=False
    )

    def invoke(setd, context, event):
        return context.window_manager.invoke_props_dialog(setd, width=420)

    def draw(setd, context):
        layout = setd.layout
        layout.label(text="Merge checked Layers")
        layout.label(text="This tool merges all currently checked td layers into one Layer.")
        layout.label(text="Check the layers you want to include before merging.")
        layout.prop(setd, "dont_show_again")

    def execute(setd, context):
        prefs = context.preferences.addons["ToKoDraw"].preferences

        if setd.dont_show_again:
            prefs.show_merge_layers_warning = False


        bpy.ops.td.merge_visible_layers('EXEC_DEFAULT')


        return {'FINISHED'}





class td_OT_merge_visible_layers(bpy.types.Operator):
    bl_idname = "td.merge_visible_layers"
    bl_label = "Merge checked layers"
    bl_description = "Merge all checked layers into the active layer."

    def invoke(setd, context, event):
        prefs = context.preferences.addons["ToKoDraw"].preferences

        if prefs.show_merge_layers_warning:
            bpy.ops.td.merge_visible_layers_info('INVOKE_DEFAULT')
            return {'FINISHED'}

        return setd.execute(context)

    def execute(setd, context):
        scene = context.scene
        obj = context.object

        if not obj or obj.type != 'MESH':
            setd.report({'ERROR'}, "Select a mesh object.")
            return {'CANCELLED'}

        mat = get_active_td_material()
        if not mat or not mat.node_tree:
            setd.report({'ERROR'}, "No active ToKoDraw material found.")
            return {'CANCELLED'}

        
        layers, nbadds = get_real_layer_nbadd_chain(mat, debug=False)
        if not layers:
            setd.report({'ERROR'}, "No td layers found.")
            return {'CANCELLED'}

        merge_map = scene.td_merge_map

        
        layer_arrays = []
        layer_blend_modes = []
        layer_opacities = []

        w = h = None

        layer_buffers = get_layer_buffer_map(scene)

        for layer_node in layers:
            uid = layer_node.get("td_uid")
            if not uid:
                print("Layer sans UID :", layer_node.name)
                continue

            merge_item = merge_map.get(uid)
            if not merge_item or not merge_item.checked:
                continue

            tex_node = get_tex_node_from_layer(layer_node)
            if not tex_node or not tex_node.image:
                continue

            img = tex_node.image
            if w is None or h is None:
                w, h = img.size

           
            arr = layer_buffers.get(uid)

            if arr is None:
                
                buf = np.empty(w * h * 4, dtype=np.float32)
                img.pixels.foreach_get(buf)
                arr = buf.reshape(w * h, 4)
                layer_buffers[uid] = arr
            else:
                
                arr = arr.copy()  

            
            rgba = arr
            alpha = rgba[:, 3]
            rgb = rgba[:, :3]

            is_processed = img.get("td_is_processed", False)

            mask = alpha < 0.02
            rgb[mask] = 0.0

        
            if not is_processed:
                rgb[~mask] *= alpha[~mask, None]

            rgb *= merge_item.opacity
            alpha *= merge_item.opacity

            rgba[:, :3] = rgb
            rgba[:, 3] = alpha

            layer_arrays.append(rgba)
            layer_blend_modes.append(merge_item.blend_mode)



        if not layer_arrays:
            setd.report({'ERROR'}, "No checked layers to merge.")
            return {'CANCELLED'}

        
        final = np.zeros((w * h, 4), dtype=np.float32)

        BLEND_FUNCS = {
            "NORMAL":   blend_normal_np,
            "MULTIPLY": blend_multiply_np,
            "SCREEN":   blend_screen_np,
            "OVERLAY":  blend_overlay_np,
        }

        for arr, mode in zip(layer_arrays, layer_blend_modes):
    
            func = BLEND_FUNCS.get(mode, blend_normal_np)
            func(final, arr, out=final)

      
        
        merged_img = bpy.data.images.new(
            name=f"td_img_merged_{obj.name}",
            width=w,
            height=h,
            alpha=True,
            float_buffer=True,
        )
        merged_img.pixels.foreach_set(final.ravel())
        merged_img.pack()
        merged_img.use_fake_user = True
        merged_img["td_is_processed"] = True
   
        base_uid = scene.td_active_layer_uid

        layers = get_layer_chain(mat)
        active_layer = next((l for l in layers if l.get("td_uid") == base_uid), None)

        tex_node = get_tex_node_from_layer(active_layer)
        tex_node.image = merged_img
        active_layer.label += " - merge"

  

        while True:

            layers = get_layer_chain(mat)
            merge_map = scene.td_merge_map

            checked = []
            for layer in layers:
                uid = layer.get("td_uid")
                if not uid or uid == base_uid:
                    continue

                merge_item = merge_map.get(uid)
                if not merge_item or not merge_item.checked:
                    continue

                checked.append(layer)

          
            if not checked:
                break

        
            layer_to_delete = checked[-1]
            uid = layer_to_delete.get("td_uid")
            index = layers.index(layer_to_delete)

            scene.td_active_layer_uid = uid
            scene.td_active_layer = layer_to_delete.name
            scene.td_active_layer_index = index

            remove_layer_merged(mat, index)

        
        layers = get_layer_chain(mat)
        base_layer = next((l for l in layers if l.get("td_uid") == base_uid), None)
        if base_layer:
            scene.td_active_layer = base_layer.name
            scene.td_active_layer_uid = base_uid
            scene.td_active_layer_index = layers.index(base_layer)

      
        for item in scene.td_merge_map:
            if item.name != base_uid:
                item.checked = False
        
       
        layers = get_layer_chain(mat)
        rebuild_merge_map(scene, layers)

      
        merge_map = scene.td_merge_map

        for item in merge_map:
            item.checked = False

        active_item = merge_map.get(base_uid)
        if active_item:
            active_item.checked = True


        layer_buffers = get_layer_buffer_map(scene)
        layer_buffers.clear()

        setd.report({'INFO'}, f"Merged image created: {merged_img.name}")
        return {'FINISHED'}




def remove_layer_merged(mat, index, spacing=200):
    
    previous_layer_index = index


    layers = get_layer_chain(mat)


    if index < 0 or index >= len(layers):
        return False

    layer_node = layers[index]


    if layer_node.node_tree.get("td_lock_layer", False):
        print("Layer is locked and cannot be removed.")
        return False



    layers = get_layer_chain(mat)
    nbadds = get_nbadd_chain(mat)



    if index <= 0:
        print("Layer 0 ne doit jamais être supprimé.")
        return
    if index >= len(layers):
        print(f"Index {index} hors limites.")
        return

    layer = layers[index]
    nb = get_nbadd_for_layer(mat, layer)
    if nb is None:
        print(f"Aucun NBAdd associé au layer {index}.")
        return



    td_tree = mat.node_tree

    emission = next((n for n in td_tree.nodes if n.bl_idname == "ShaderNodeEmission"), None)
    bsdf = next((n for n in td_tree.nodes if n.bl_idname == "ShaderNodeBsdfPrincipled"), None)
    mixshad = next((n for n in td_tree.nodes if n.bl_idname == "ShaderNodeMixShader"), None)



    nb_index = nbadds.index(nb)
    prev_nb = nbadds[nb_index - 1] if nb_index > 0 else None
    next_nb = nbadds[nb_index + 1] if nb_index < len(nbadds) - 1 else None
    


    for socket in nb.inputs:
        for link in list(socket.links):
            td_tree.links.remove(link)
    for socket in nb.outputs:
        for link in list(socket.links):
            td_tree.links.remove(link)
            



    if index == 1 and next_nb:
        layer0 = layers[0]


        td_tree.links.new(layer0.outputs["Color"], next_nb.inputs["Below_Color"])
        td_tree.links.new(layer0.outputs["Alpha"], next_nb.inputs["Below_Alpha"])


        if len(layers) > 2:
            layer2 = layers[2]
            td_tree.links.new(layer2.outputs["Color"], next_nb.inputs["Layer_Color"])
            td_tree.links.new(layer2.outputs["Alpha"], next_nb.inputs["Layer_Alpha"])

    else:



        if prev_nb and next_nb:
            td_tree.links.new(prev_nb.outputs["Out_Color"], next_nb.inputs["Below_Color"])
            td_tree.links.new(prev_nb.outputs["Out_Alpha"], next_nb.inputs["Below_Alpha"])

   


    if emission:
        if not emission.inputs["Color"].links:
            remaining = [n for n in nbadds if n != nb]
            if remaining:
                last_nbadd = remaining[-1]
                color_out = next((s for s in last_nbadd.outputs if "Color" in s.name), None)
                if emission and color_out:
                    td_tree.links.new(color_out, emission.inputs["Color"])


    if mixshad:
        if not mixshad.inputs["Fac"].links:
            remaining = [n for n in nbadds if n != nb]
            if remaining:
                last_nbadd = remaining[-1]
                alpha_out = next((s for s in last_nbadd.outputs if "Alpha" in s.name), None)
                if mixshad and alpha_out:
                    td_tree.links.new(alpha_out, mixshad.inputs["Fac"])


    if bsdf:
        if not bsdf.inputs["Base Color"].links:
            remaining = [n for n in nbadds if n != nb]
            if remaining:
                last_nbadd = remaining[-1]
                color_out = next((s for s in last_nbadd.outputs if "Color" in s.name), None)
                alpha_out = next((s for s in last_nbadd.outputs if "Alpha" in s.name), None)
                if bsdf and color_out:
                    td_tree.links.new(color_out, bsdf.inputs["Base Color"])
                if bsdf and alpha_out:
                    td_tree.links.new(alpha_out, bsdf.inputs["Alpha"])




    db = layer.node_tree
    if db:
        for sub in db.nodes:
            if sub.type == 'TEX_IMAGE' and sub.image:
                sub.image = None


    layer_uid = layer.get("td_uid")

    for img in list(bpy.data.images):
        if img.get("td_uid") == layer_uid:
            bpy.data.images.remove(img)

    layer_uid = layer.get("td_uid")


    for ng in list(bpy.data.node_groups):
        if ng.get("td_layer_uid") == layer_uid and ng.get("td_feature") == "HARD_ALPHA":
            bpy.data.node_groups.remove(ng)


    for ng in list(bpy.data.node_groups):
        if ng.get("td_uid") == layer_uid:
            bpy.data.node_groups.remove(ng)


    nb_group = nb.node_tree

    if nb_group:
        uid = nb_group.get("td_uid")
        for ng in list(bpy.data.node_groups):
            if ng.get("td_uid") == uid:
                bpy.data.node_groups.remove(ng)



    td_tree.nodes.remove(nb)
    td_tree.nodes.remove(layer)


    new_layers = get_layer_chain(mat)
    new_nbadds = get_nbadd_chain(mat)




    if len(new_layers) == 1 and len(new_nbadds) == 0:
        layer0 = new_layers[0]


        td_tree.links.new(layer0.outputs["Color"], emission.inputs["Color"])
        td_tree.links.new(layer0.outputs["Alpha"], mixshad.inputs["Fac"])
        td_tree.links.new(layer0.outputs["Color"], bsdf.inputs["Base Color"])
        td_tree.links.new(layer0.outputs["Alpha"], bsdf.inputs["Alpha"])

    


    for i, layer in enumerate(new_layers):
        layer.location.y = 200 - (i + 1) * spacing


    for i, nb in enumerate(new_nbadds):
        nb.location.y = 200 - (i + 2) * spacing



    scene = bpy.context.scene


    layers = get_layer_chain(mat)
    nbadds = get_nbadd_chain(mat)


    for i, layer in enumerate(layers):
        layer["td_index"] = i


    for i, nb in enumerate(nbadds, start=1):
        nb["td_index"] = i


    for i, nb in enumerate(nbadds, start=1):
        base_label = nb.label if nb.label else nb.name
        nb.label = f"{base_label.split('[')[0].strip()} [{i}]"


    for layer in layers:
        tex = get_tex_node_from_layer(layer)
        if tex and tex.image:
            img = tex.image
            base_label = tex.label if tex.label else tex.name
            tex.label = f"{base_label.split('[')[0].strip()} [{layer['td_index']}]"
                
    return {'FINISHED'}
    



class td_OT_bake_simple(bpy.types.Operator):
    bl_idname = "td.bake_simple"
    bl_label = "Bake Combined td Layers"
    bl_description = "Bake all visible td layers into one image and create a simple material (Emission or BSDF + Normal)."

    def execute(setd, context):
        scene = context.scene
        obj = context.object

        if not obj or obj.type != 'MESH':
            setd.report({'ERROR'}, "Sélectionne un mesh.")
            return {'CANCELLED'}

        mat = get_active_td_material()
        if not mat or not mat.node_tree:
            setd.report({'ERROR'}, "Aucun matériau ToKoDraw actif.")
            return {'CANCELLED'}


        layers, nbadds = get_real_layer_nbadd_chain(mat, debug=False)
        if not layers:
            setd.report({'ERROR'}, "Aucun layer td trouvé.")
            return {'CANCELLED'}

        layer_buffers = get_layer_buffer_map(scene)
        arrays = []

        w = h = None

        for layer_node in layers:
            tex_node = get_tex_node_from_layer(layer_node)
            if not tex_node or not tex_node.image:
                continue


            if tex_node.mute:
                continue

            img = tex_node.image

            if w is None or h is None:
                w, h = img.size

            uid = layer_node.get("td_uid")
            arr = None


            if uid and uid in layer_buffers:
                arr = layer_buffers[uid].copy()


            if arr is None:
                buf = np.empty(w * h * 4, dtype=np.float32)
                img.pixels.foreach_get(buf)
                arr = buf.reshape(w * h, 4)

            arrays.append(arr)

        if not arrays:
            setd.report({'ERROR'}, "Aucune image visible à baker.")
            return {'CANCELLED'}


        N = w * h
        final = np.zeros((N, 4), dtype=np.float32)

        def alpha_over(bottom, top):
            a_t = top[:, 3:4]
            a_b = bottom[:, 3:4]
            out_rgb = top[:, :3] * a_t + bottom[:, :3] * a_b * (1 - a_t)
            out_a   = a_t + a_b * (1 - a_t)
            return np.concatenate([out_rgb, out_a], axis=1)

        for arr in arrays:
            final = alpha_over(final, arr)


        bake_img = bpy.data.images.new(
            name=f"td_Bake_{obj.name}",
            width=w,
            height=h,
            alpha=True,
            float_buffer=True,
        )

        bake_img.colorspace_settings.name = 'sRGB'
        bake_img.pixels.foreach_set(final.reshape(-1))
        bake_img.update()
        bake_img.pack()


        td_bsdf = mat.node_tree.nodes.get("Principled BSDF")
        td_emission = mat.node_tree.nodes.get("Emission")


        normal_img = None

        if td_bsdf and td_bsdf.inputs["Normal"].is_linked:
            normal_link = td_bsdf.inputs["Normal"].links[0]
            normal_node = normal_link.from_node

            if isinstance(normal_node, bpy.types.ShaderNodeNormalMap):
                if normal_node.inputs["Color"].is_linked:
                    tex_node = normal_node.inputs["Color"].links[0].from_node
                    if isinstance(tex_node, bpy.types.ShaderNodeTexImage):
                        normal_img = tex_node.image


        bake_mat = bpy.data.materials.new(name=f"td_Bake_Mat_{obj.name}")
        bake_mat.use_nodes = True
        nt2 = bake_mat.node_tree

        for n in nt2.nodes:
            nt2.nodes.remove(n)

        out = nt2.nodes.new("ShaderNodeOutputMaterial")


        if td_emission and not td_bsdf:
            tex = nt2.nodes.new("ShaderNodeTexImage")
            tex.image = bake_img

            transparent = nt2.nodes.new("ShaderNodeBsdfTransparent")
            emission = nt2.nodes.new("ShaderNodeEmission")
            mix = nt2.nodes.new("ShaderNodeMixShader")

            nt2.links.new(tex.outputs["Color"], emission.inputs["Color"])
            nt2.links.new(tex.outputs["Alpha"], mix.inputs["Fac"])
            nt2.links.new(transparent.outputs[0], mix.inputs[1])
            nt2.links.new(emission.outputs[0], mix.inputs[2])
            nt2.links.new(mix.outputs[0], out.inputs["Surface"])

            bake_mat.blend_method = 'BLEND'


        else:
            tex = nt2.nodes.new("ShaderNodeTexImage")
            tex.image = bake_img

            bsdf = nt2.nodes.new("ShaderNodeBsdfPrincipled")
            nt2.links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
            nt2.links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])


            if normal_img:
                normal_tex = nt2.nodes.new("ShaderNodeTexImage")
                normal_tex.image = normal_img

                normal_map = nt2.nodes.new("ShaderNodeNormalMap")
                nt2.links.new(normal_tex.outputs["Color"], normal_map.inputs["Color"])
                nt2.links.new(normal_map.outputs["Normal"], bsdf.inputs["Normal"])

            bake_mat.blend_method = 'OPAQUE'


        obj.data.materials.clear()
        obj.data.materials.append(bake_mat)


        layer_buffers.clear()

        setd.report({'INFO'}, "Bake Simple terminé.")
        return {'FINISHED'}
