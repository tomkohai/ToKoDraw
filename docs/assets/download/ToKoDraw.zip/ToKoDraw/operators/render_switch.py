import bpy
from bpy.types import Operator


class td_OT_render_switch(Operator):
    bl_idname = "td.render_switch"
    bl_label = "Render Switch"
    bl_description = "Switch the ToKoDraw shader output between Emission and BSDF"

    def execute(setd, context):
        obj = context.object
        if not obj or not obj.active_material:
            setd.report({'ERROR'}, "Aucun matériau actif.")
            return {'CANCELLED'}

        mat = obj.active_material
        td_tree = mat.node_tree

        emission = next((n for n in td_tree.nodes if n.bl_idname == "ShaderNodeEmission"), None)
        mixshad  = next((n for n in td_tree.nodes if n.bl_idname == "ShaderNodeMixShader"), None)
        bsdf     = next((n for n in td_tree.nodes if n.bl_idname == "ShaderNodeBsdfPrincipled"), None)

        output = next((n for n in td_tree.nodes if n.bl_idname == "ShaderNodeOutputMaterial"), None)
        socket = output.inputs["Surface"]


        current = socket.links[0].from_node if socket.links else None


        for link in list(socket.links):
            td_tree.links.remove(link)


        if current and current.bl_idname == "ShaderNodeMixShader":

            td_tree.links.new(bsdf.outputs["BSDF"], socket)
            context.scene.td_show_normalmap_panel = True
            setd.report({'INFO'}, "Render mode : BSDF")

        else:

            td_tree.links.new(mixshad.outputs["Shader"], socket)
            context.scene.td_show_normalmap_panel = False
            setd.report({'INFO'}, "Render mode : Emission")

        return {'FINISHED'}
