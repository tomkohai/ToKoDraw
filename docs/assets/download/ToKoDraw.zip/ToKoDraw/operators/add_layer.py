
from uuid import uuid4

import bpy

from ..core.node_groups import (
    create_td_layer, 
    create_td_nbadd,
)
from ..core.layer_chain_utils import (
    get_layer_chain,
    get_nbadd_chain,
)

from ..core.layer_utils import get_tex_node_from_layer

from ..properties.props import rebuild_merge_map

from .layer_settings import td_OT_post_duplicate

from .normal_settings import td_OT_post_normalmap




class td_OT_choose_layer_size(bpy.types.Operator):
    """Add Layer or Normal Map Layer and Set Size"""
    bl_idname = "td.choose_layer_size"
    bl_label = "Add Layer (Set Size)"
    bl_options = {'REGISTER', 'UNDO'}

    size_options: bpy.props.EnumProperty(
        name="Preset Sizes",
        items=[
            ('512', '512x512', 'Small (Fast)'),
            ('1024', '1024x1024', 'Medium'),
            ('2048', '2048x2048', 'Large (Default)'),
            ('4096', '4096x4096', 'Very Large'),
            ('CUSTOM', 'Custom', 'Define your own size'),
        ],
        default='2048'
    )

    custom_size: bpy.props.IntProperty(
        name="Custom Size",
        default=2048,
        min=16,
        max=8192,
    )
    
    create_normal: bpy.props.BoolProperty(
        name="Create Normal Map Image",
        default=False
    )

    bit_depth: bpy.props.EnumProperty(
        name="Bit Depth",
        items=[
            ('8', "8-bit", ""),
            ('16', "16-bit", ""),
            ('32', "32-bit Float", "")
        ],
        default='32'
    )

    def draw(setd, context):
        layout = setd.layout
        layout.prop(setd, "size_options", text="Preset")
        if setd.size_options == 'CUSTOM':
            layout.prop(setd, "custom_size", text="Size")

        layout.separator()
        layout.prop(setd, "create_normal")

        if setd.create_normal:
            layout.prop(setd, "bit_depth")

    def invoke(setd, context, event):

        return context.window_manager.invoke_props_dialog(setd)

    def execute(setd, context):
        size = setd.custom_size if setd.size_options == 'CUSTOM' else int(setd.size_options)

        if setd.create_normal:
            bpy.ops.td.add_layer(
                size=size,
                normal_mode=True,
                bit_depth=setd.bit_depth
            )
        else:
            bpy.ops.td.add_layer(size=size)

        setd.report({'INFO'}, f"Layer added with size: {size}")
        return {'FINISHED'}





class td_OT_add_layer(bpy.types.Operator):
    bl_idname = "td.add_layer"
    bl_label = "Add Layer"
    bl_description = "Add a new paint layer to the ToKoDraw material"


    size: bpy.props.IntProperty(
        name="Layer Size",
        default=2048,
        min=16,
        max=8192,
    )


    duplicate_mode: bpy.props.BoolProperty(default=False)


    duplicate_from: bpy.props.StringProperty(default="")


    normal_mode: bpy.props.BoolProperty(default=False)


    bit_depth: bpy.props.StringProperty(default="32")


    def execute(setd, context):
        scene = context.scene
        obj = context.object
        mat = obj.active_material
    
        

        size = setd.size 
        

        duplicate_mode = setd.duplicate_mode
        duplicate_from = setd.duplicate_from


        if not mat or "td_layer_count" not in mat:
            setd.report({'ERROR'}, "Not a ToKoDraw material")
            return {'CANCELLED'}

        

        layers = get_layer_chain(mat)
        nbadds = get_nbadd_chain(mat)


        if not layers:
            setd.report({'ERROR'}, "No ToKoDraw layers found")
            return {'CANCELLED'}


        active_index = scene.td_active_layer_index
        if active_index < 0:
            active_index = len(layers) - 1

        insert_index = min(active_index + 1, len(layers))

        new_index = len(layers)


        mat["td_layer_count"] = new_index + 1

        td_layer_count = mat["td_layer_count"]





        

        td_id = mat.get("td_id")
        if not td_id:
            setd.report({'ERROR'}, "Material has no td_id")
            return {'CANCELLED'}

        new_layer = mat.node_tree.nodes.new("ShaderNodeGroup")

        mat_index = mat.get("td_mat_index")
        ng, layer_uid = create_td_layer(mat_index, new_index, size=setd.size)


        new_layer.node_tree = ng
        



        existing_name_indices = []

        for layer in layers:
            name = layer.name  
            try:

                suffix = name.split("Layer_")[1]

                suffix = suffix.split(".")[0]
                idx = int(suffix)
                existing_name_indices.append(idx)
            except (IndexError, ValueError):
                continue  

        if existing_name_indices:
            real_index = max(existing_name_indices) + 1
        else:
            real_index = 1  

        new_layer.name = f"td{mat_index}_Layer_{real_index}"
        new_layer.label = f"td_Layer_{real_index}"
        new_layer.node_tree.name = f"td{mat_index}_Layer_{real_index}"





        new_layer.location = (-1100, 200 - (insert_index + 1) * 200)

        

        new_layer["td_uid"] = layer_uid

        new_layer["td_index"] = new_index



        tex = new_layer.node_tree.nodes.get("Texture")
        if tex:
            uid = new_layer["td_uid"]
            img = bpy.data.images.get(f"td_IMG_{uid}")
            if img:
                tex.image = img



        em = next((n for n in mat.node_tree.nodes if isinstance(n, bpy.types.ShaderNodeEmission)), None)
        bsdf = next((n for n in mat.node_tree.nodes if isinstance(n, bpy.types.ShaderNodeBsdfPrincipled)), None)
        mixshad = next((n for n in mat.node_tree.nodes if isinstance(n, bpy.types.ShaderNodeMixShader)), None)
        if not em or not bsdf or not mixshad:
            setd.report({'ERROR'}, "Missing Emission or BSDF in ToKoDraw")
            return {'CANCELLED'}

        
        








        if insert_index == 0:

            below_color = None
            below_alpha = None

        elif insert_index == 1:

            below_layer = layers[0]
            below_color = below_layer.outputs["Color"]
            below_alpha = below_layer.outputs["Alpha"]

        else:

            prev_nb = nbadds[insert_index - 2]
            below_color = prev_nb.outputs["Out_Color"]
            below_alpha = prev_nb.outputs["Out_Alpha"]



        if insert_index < len(nbadds) + 1:

            above_nb = nbadds[insert_index - 1]
        else:

            above_nb = None



        existing_nbadd_indices = []

        for nb in nbadds:

            existing_nbadd_indices.append(nb["td_index"])


        if existing_nbadd_indices:
            nbadd_index = max(existing_nbadd_indices) + 1
        else:

            nbadd_index = 1

        ng = create_td_nbadd(mat_index, nbadd_index)


        nbadd = mat.node_tree.nodes.new("ShaderNodeGroup")
        nbadd.node_tree = ng
        nbadd.name = f"td{mat_index}_NBAdd_{nbadd_index}"
        nbadd.label = nbadd.name

        nbadd["td_uid"] = uuid4().hex
        nbadd["td_index"] = nbadd_index

        nbadd.location = (-900, 200 - (insert_index + 1) * 200)



        if insert_index < len(layers):


            for idx, layer in enumerate(layers):
                if idx >= insert_index:
                    layer.location = (-1100, 200 - (idx + 2) * 200)



        if above_nb:

            above_nb.location.y -= 200


            start = False
            for nb in nbadds:
                if nb is above_nb:
                    start = True
                    continue
                if start:
                    nb.location.y -= 200



        td_links = mat.node_tree.links

    
        if below_color:
            td_links.new(below_color, nbadd.inputs["Below_Color"])
            td_links.new(below_alpha, nbadd.inputs["Below_Alpha"])



        td_links.new(new_layer.outputs["Color"], nbadd.inputs["Layer_Color"])
        td_links.new(new_layer.outputs["Alpha"], nbadd.inputs["Layer_Alpha"])



        if above_nb:

            for link in list(above_nb.inputs["Below_Color"].links):
                td_links.remove(link)
            for link in list(above_nb.inputs["Below_Alpha"].links):
                td_links.remove(link)


            td_links.new(nbadd.outputs["Out_Color"], above_nb.inputs["Below_Color"])
            td_links.new(nbadd.outputs["Out_Alpha"], above_nb.inputs["Below_Alpha"])

        else:

            for link in list(em.inputs["Color"].links):
                td_links.remove(link)
            for link in list(mixshad.inputs["Fac"].links):
                td_links.remove(link)
            for link in list(bsdf.inputs["Base Color"].links):
                td_links.remove(link)
            for link in list(bsdf.inputs["Alpha"].links):
                td_links.remove(link)

            td_links.new(nbadd.outputs["Out_Color"], em.inputs["Color"])
            td_links.new(nbadd.outputs["Out_Alpha"], mixshad.inputs["Fac"])
            td_links.new(nbadd.outputs["Out_Color"], bsdf.inputs["Base Color"])
            td_links.new(nbadd.outputs["Out_Alpha"], bsdf.inputs["Alpha"])





     
        new_active_index = new_index
        new_active_layer = new_layer
        new_tex_image = tex.image if tex and tex.image else None

        scene = bpy.context.scene


        scene.td_active_layer = new_layer.name
        scene.td_active_layer_uid = new_layer.get("td_uid")
        scene.td_active_layer_index = insert_index


        scene.tool_settings.image_paint.canvas = new_tex_image


        new_layer.select = True
        mat.node_tree.nodes.active = new_layer


        new_layer.inputs["Opacity"].default_value = 1.0
        scene.td_active_opacity = 1.0


        if duplicate_mode and duplicate_from:

            td_tree = mat.node_tree
            td_layers = [n for n in td_tree.nodes if n.get("td_uid") and "Layer" in n.name]
            new_layer_uid = td_layers[-1].get("td_uid")

            bpy.ops.td.post_duplicate(
                new_layer_uid=new_layer_uid,
                src_layer_uid=duplicate_from
            )


        if setd.normal_mode:
            bpy.ops.td.post_normalmap(
                new_layer_uid=new_layer.get("td_uid"),
                bit_depth=setd.bit_depth
            )


        layers = get_layer_chain(mat)
        rebuild_merge_map(scene, layers)


        merge_map = scene.td_merge_map


        for item in merge_map:
            item.checked = False


        active_uid = scene.td_active_layer_uid
        active_item = merge_map.get(active_uid)
        if active_item:
            active_item.checked = True






        layers = get_layer_chain(mat)
        nbadds = get_nbadd_chain(mat)


        for i, layer in enumerate(layers):
            layer["td_index"] = i


        for i, nb in enumerate(nbadds, start=1):  
            nb["td_index"] = i

     

      
        for i, nb in enumerate(nbadds, start=1):
            base_label = nb.label if nb.label else nb.name
            nb.label = f"{base_label.split('[')[0].strip()} [{i}]"

       
        for layer in layers:
            tex = get_tex_node_from_layer(layer)
            if tex and tex.image:
                img = tex.image
                base_label = tex.label if tex.label else tex.name
                tex.label = f"{base_label.split('[')[0].strip()} [{layer['td_index']}]"

        return {'FINISHED'}