import bpy
import sys
import importlib


from .create_material import (
    td_OT_create_material_popup,
    td_OT_create_material,
    td_OT_canvas_setup_popup,
)

from .add_layer import td_OT_add_layer, td_OT_choose_layer_size
from .select_layer import td_OT_select_layer
from .set_opacity import td_OT_set_opacity, update_opacity
from .remove_material import td_OT_remove_material
from .remove_layer import td_OT_remove_layer
from .render_switch import td_OT_render_switch

from .layer_settings import (
    td_OT_open_layer_settings,
    td_OT_toggle_layer_visibility,
    td_OT_toggle_layer_solo,
    td_OT_rename_layer,
    td_OT_toggle_lock_alpha,
    td_OT_lock_alpha_warning,
    td_OT_toggle_lock_layer,
    td_OT_lock_layer_warning,
    td_OT_duplicate_layer,
    td_OT_post_duplicate,
    td_OT_reset_popups,
    td_OT_new_image,
    td_OT_import_image,
    td_OT_remove_image,
    
)

from .normal_settings import (
    td_OT_post_normalmap,
    td_OT_normal_import,
    td_OT_normal_rename,
    td_OT_normal_remove,
)

from .reorder_layer import (
    td_OT_move_layer_up,
    td_OT_move_layer_down,
    td_OT_reorder_layer,
   
)

from .mesh_outline import (
    td_OT_outline, 
    td_OT_add_outline,
    td_PT_outline_window,
    td_OT_delete_outline,
    update_outline_thickness,
)

from .lineart_gp import (
    td_OT_lineart,
    td_OT_add_lineart,
    td_PT_lineart_window,
    td_OT_delete_lineart,
)

from .cam_view import (
    td_OT_set_camera_view,
    td_OT_toggle_camview,
    td_OT_obj_transform,
    td_OT_reset_transform,
)

from .merge_layers import (
    td_OT_merge_visible_layers,
    td_OT_merge_visible_layers_info,
    td_OT_bake_simple,
)

operator_classes = (


    td_OT_create_material_popup,
    td_OT_canvas_setup_popup,
    td_OT_create_material,
    td_OT_choose_layer_size,
    td_OT_add_layer,
    td_OT_select_layer,
    td_OT_set_opacity,
    td_OT_remove_material,
    td_OT_remove_layer,
    td_OT_render_switch,
    td_OT_open_layer_settings,
    td_OT_toggle_layer_visibility,
    td_OT_toggle_layer_solo,
    td_OT_rename_layer,
    td_OT_toggle_lock_alpha,
    td_OT_lock_alpha_warning,
    td_OT_toggle_lock_layer,
    td_OT_lock_layer_warning,
    td_OT_duplicate_layer,
    td_OT_post_duplicate,
    td_OT_reset_popups,
    td_OT_move_layer_up,
    td_OT_move_layer_down,
    td_OT_reorder_layer,
    td_OT_new_image,
    td_OT_import_image,
    td_OT_remove_image,
    td_OT_post_normalmap,
    td_OT_normal_import,
    td_OT_normal_rename,
    td_OT_normal_remove,



    td_OT_merge_visible_layers, 
    td_OT_merge_visible_layers_info,
    td_OT_bake_simple, 
   


    td_OT_outline, 
    td_OT_add_outline,
    td_PT_outline_window,
    td_OT_delete_outline,

    

    td_OT_lineart,
    td_OT_add_lineart,
    td_PT_lineart_window,
    td_OT_delete_lineart,


    td_OT_set_camera_view,
    td_OT_toggle_camview,
    td_OT_obj_transform,
    td_OT_reset_transform,
)



