import bpy
from bpy.types import Operator

from ..core.layer_chain_utils import (
    get_layer_chain,
    get_nbadd_chain,
    get_nbadd_for_layer,
)
from ..core.layer_utils import (
    get_active_layer_image,
    get_tex_node_from_layer,
)

from ..properties.props import rebuild_merge_map





def remove_layer_at_index(mat, index, spacing=200):
    
    previous_layer_index = index


    layers = get_layer_chain(mat)


    if index < 0 or index >= len(layers):
        return False

    layer_node = layers[index]


    if layer_node.node_tree.get("td_lock_layer", False):
        print("Layer is locked and cannot be removed.")
        return False



    layers = get_layer_chain(mat)
    nbadds = get_nbadd_chain(mat)



    if index <= 0:
        print("Layer 0 ne doit jamais être supprimé.")
        return
    if index >= len(layers):
        print(f"Index {index} hors limites.")
        return

    layer = layers[index]
    nb = get_nbadd_for_layer(mat, layer)
    if nb is None:
        print(f"Aucun NBAdd associé au layer {index}.")
        return



    td_tree = mat.node_tree

    emission = next((n for n in td_tree.nodes if n.bl_idname == "ShaderNodeEmission"), None)
    bsdf = next((n for n in td_tree.nodes if n.bl_idname == "ShaderNodeBsdfPrincipled"), None)
    mixshad = next((n for n in td_tree.nodes if n.bl_idname == "ShaderNodeMixShader"), None)



    nb_index = nbadds.index(nb)
    prev_nb = nbadds[nb_index - 1] if nb_index > 0 else None
    next_nb = nbadds[nb_index + 1] if nb_index < len(nbadds) - 1 else None
    


    for socket in nb.inputs:
        for link in list(socket.links):
            td_tree.links.remove(link)
    for socket in nb.outputs:
        for link in list(socket.links):
            td_tree.links.remove(link)
            



    if index == 1 and next_nb:
        layer0 = layers[0]


        td_tree.links.new(layer0.outputs["Color"], next_nb.inputs["Below_Color"])
        td_tree.links.new(layer0.outputs["Alpha"], next_nb.inputs["Below_Alpha"])


        if len(layers) > 2:
            layer2 = layers[2]
            td_tree.links.new(layer2.outputs["Color"], next_nb.inputs["Layer_Color"])
            td_tree.links.new(layer2.outputs["Alpha"], next_nb.inputs["Layer_Alpha"])

    else:



        if prev_nb and next_nb:
            td_tree.links.new(prev_nb.outputs["Out_Color"], next_nb.inputs["Below_Color"])
            td_tree.links.new(prev_nb.outputs["Out_Alpha"], next_nb.inputs["Below_Alpha"])

   


    if emission:
        if not emission.inputs["Color"].links:
            remaining = [n for n in nbadds if n != nb]
            if remaining:
                last_nbadd = remaining[-1]
                color_out = next((s for s in last_nbadd.outputs if "Color" in s.name), None)
                if emission and color_out:
                    td_tree.links.new(color_out, emission.inputs["Color"])


    if mixshad:
        if not mixshad.inputs["Fac"].links:
            remaining = [n for n in nbadds if n != nb]
            if remaining:
                last_nbadd = remaining[-1]
                alpha_out = next((s for s in last_nbadd.outputs if "Alpha" in s.name), None)
                if mixshad and alpha_out:
                    td_tree.links.new(alpha_out, mixshad.inputs["Fac"])


    if bsdf:
        if not bsdf.inputs["Base Color"].links:
            remaining = [n for n in nbadds if n != nb]
            if remaining:
                last_nbadd = remaining[-1]
                color_out = next((s for s in last_nbadd.outputs if "Color" in s.name), None)
                alpha_out = next((s for s in last_nbadd.outputs if "Alpha" in s.name), None)
                if bsdf and color_out:
                    td_tree.links.new(color_out, bsdf.inputs["Base Color"])
                if bsdf and alpha_out:
                    td_tree.links.new(alpha_out, bsdf.inputs["Alpha"])




    db = layer.node_tree
    if db:
        for sub in db.nodes:
            if sub.type == 'TEX_IMAGE' and sub.image:
                sub.image = None


    layer_uid = layer.get("td_uid")

    for img in list(bpy.data.images):
        if img.get("td_uid") == layer_uid:
            bpy.data.images.remove(img)

    layer_uid = layer.get("td_uid")


    for ng in list(bpy.data.node_groups):
        if ng.get("td_layer_uid") == layer_uid and ng.get("td_feature") == "HARD_ALPHA":
            bpy.data.node_groups.remove(ng)


    for ng in list(bpy.data.node_groups):
        if ng.get("td_uid") == layer_uid:
            bpy.data.node_groups.remove(ng)


    nb_group = nb.node_tree

    if nb_group:
        uid = nb_group.get("td_uid")
        for ng in list(bpy.data.node_groups):
            if ng.get("td_uid") == uid:
                bpy.data.node_groups.remove(ng)



    td_tree.nodes.remove(nb)
    td_tree.nodes.remove(layer)


    new_layers = get_layer_chain(mat)
    new_nbadds = get_nbadd_chain(mat)




    if len(new_layers) == 1 and len(new_nbadds) == 0:
        layer0 = new_layers[0]


        td_tree.links.new(layer0.outputs["Color"], emission.inputs["Color"])
        td_tree.links.new(layer0.outputs["Alpha"], mixshad.inputs["Fac"])
        td_tree.links.new(layer0.outputs["Color"], bsdf.inputs["Base Color"])
        td_tree.links.new(layer0.outputs["Alpha"], bsdf.inputs["Alpha"])

        



    scene = bpy.context.scene


    if new_layers:

        if index < len(new_layers):
            new_active = new_layers[index]
        else:

            new_active = new_layers[-1]

        scene.td_active_layer = new_active.name
        scene.td_active_layer_index = new_active["td_index"]

    else:

        scene.td_active_layer = ""
        scene.td_active_layer_index = -1
    
   
    used_uids = set()

    for layer in new_layers:
        db = layer.node_tree
        if not db:
            continue

        for sub in db.nodes:
            if sub.type == 'TEX_IMAGE' and sub.image:
                if "td_uid" in sub.image:
                    used_uids.add(sub.image["td_uid"])


    for img in list(bpy.data.images):
        if "td_uid" in img and img["td_uid"] not in used_uids:
            bpy.data.images.remove(img)

    






    for i, layer in enumerate(new_layers):
        layer.location.y = 200 - (i + 1) * spacing


    for i, nb in enumerate(new_nbadds):
        nb.location.y = 200 - (i + 2) * spacing








    scene = bpy.context.scene


    layers = get_layer_chain(mat)

    if layers:

        new_active_index = min(previous_layer_index, len(layers) - 1)
        new_active_layer = layers[new_active_index]


        scene.td_active_layer_index = new_active_index
        scene.td_active_layer = new_active_layer.name


        td_nodes = td_tree.nodes
        for n in td_nodes:
            n.select = False

        new_active_layer.select = True
        td_tree.nodes.active = new_active_layer
        bpy.ops.td.select_layer(layer_name=new_active_layer.name, layer_uid=new_active_layer.get("td_uid"))


        tex = next((n for n in new_active_layer.node_tree.nodes if n.type == "TEX_IMAGE"), None)
        if tex and tex.image:
            scene.tool_settings.image_paint.canvas = tex.image


        layers = get_layer_chain(mat)
        rebuild_merge_map(scene, layers)


        merge_map = scene.td_merge_map


        for item in merge_map:
            item.checked = False

      

        active_uid = scene.td_active_layer_uid
        active_item = merge_map.get(active_uid)
        if active_item:
            active_item.checked = True

    else:

        scene.td_active_layer_index = -1
        scene.td_active_layer = ""
        scene.tool_settings.image_paint.canvas = None





    layers = get_layer_chain(mat)
    nbadds = get_nbadd_chain(mat)


    for i, layer in enumerate(layers):
        layer["td_index"] = i


    for i, nb in enumerate(nbadds, start=1):
        nb["td_index"] = i

    
    for i, nb in enumerate(nbadds, start=1):
        base_label = nb.label if nb.label else nb.name
        nb.label = f"{base_label.split('[')[0].strip()} [{i}]"

    
        for layer in layers:
            tex = get_tex_node_from_layer(layer)
            if tex and tex.image:
                img = tex.image
                base_label = tex.label if tex.label else tex.name
                tex.label = f"{base_label.split('[')[0].strip()} [{layer['td_index']}]"
                

    
    return {'FINISHED'}






class td_OT_remove_layer(Operator):
    bl_idname = "td.remove_layer"
    bl_label = "Remove Layer"
    bl_description = "Remove the selected Layer"

    def execute(setd, context):
        mat = context.object.active_material
        index = context.scene.td_active_layer_index

        ok = remove_layer_at_index(mat, index)

        if not ok:
            setd.report({'WARNING'}, "Layer is locked and cannot be removed.")
            return {'CANCELLED'}

        return {'FINISHED'}

