import bpy
from ..core.layer_utils import (
    get_hardalpha_node,
    get_tex_node_from_layer,
)

from ..core.layer_chain_utils import (
    get_layer_chain,
    get_nbadd_chain,
)


class td_OT_remove_material(bpy.types.Operator):
    bl_idname = "td.remove_material"
    bl_label = "Remove ToKoDraw Material"
    bl_description = "Remove the ToKoDraw material and clear the layer system"

    def invoke(setd, context, event):
        return context.window_manager.invoke_confirm(setd, event)

    def execute(setd, context):
        obj = context.object
        mat = obj.active_material

        if not mat or "td_id" not in mat:
            setd.report({'ERROR'}, "Not a ToKoDraw material")
            return {'CANCELLED'}

        nt = mat.node_tree


        was_cam_view = False
        cam_area = None
        cam_region = None

        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    space = area.spaces.active
                    if space.region_3d.view_perspective == 'CAMERA':
                        was_cam_view = True
                        cam_area = area
                        for region in area.regions:
                            if region.type == 'WINDOW':
                                cam_region = region
                        break




        layer_uids = set()
        layers = get_layer_chain(mat)

        for layer_node in layers:
            uid = layer_node.get("td_uid")
            if uid:
                layer_uids.add(uid)




        for uid in layer_uids:
            for ng in list(bpy.data.node_groups):
                if ng.get("td_layer_uid") == uid and ng.get("td_feature") == "HARD_ALPHA":
                    bpy.data.node_groups.remove(ng)





        nbadds = get_nbadd_chain(mat)

        for nb_node in nbadds:
            nb_group = nb_node.node_tree
            if not nb_group:
                continue

            nb_uid = nb_group.get("td_uid")


            for ng in list(bpy.data.node_groups):
                if ng.get("td_uid") == nb_uid:
                    bpy.data.node_groups.remove(ng)


            nt.nodes.remove(nb_node)





        

        for img in list(bpy.data.images):
            if img.get("td_uid") in layer_uids:
                bpy.data.images.remove(img)
        



        extra_images_to_delete = set()


        for node in nt.nodes:
            if hasattr(node, "image") and node.image:
                extra_images_to_delete.add(node.image)


            if node.type == 'GROUP' and node.node_tree:
                for subnode in node.node_tree.nodes:
                    if hasattr(subnode, "image") and subnode.image:
                        extra_images_to_delete.add(subnode.image)


        for img in extra_images_to_delete:
            try:
                bpy.data.images.remove(img)
            except:
                pass






        for layer_node in layers:
            uid = layer_node.get("td_uid")
            if not uid:
                continue


            for ng in list(bpy.data.node_groups):
                if ng.get("td_uid") == uid:
                    bpy.data.node_groups.remove(ng)


            nt.nodes.remove(layer_node)

        
        





        for prop in ("td_id", "td_layer_count", "td_active_layer",
                     "td_active_layer_index", "td_active_opacity"):
            if prop in mat:
                del mat[prop]

        

        for i, slot in enumerate(obj.material_slots):
            if slot.material == mat:
                obj.active_material_index = i
                bpy.ops.object.material_slot_remove()
                break

        if mat.name in bpy.data.materials:
            bpy.data.materials.remove(mat)






        if was_cam_view and cam_area:
            space = cam_area.spaces.active
            if space.region_3d.view_perspective == 'CAMERA':

                space.lock_camera = False


                space.region_3d.view_perspective = 'PERSP'


                with context.temp_override(area=cam_area, region=cam_region):

                    bpy.ops.view3d.view_all(use_all_regions=False)


                for region in cam_area.regions:
                    if region.type == 'WINDOW':
                        region.tag_redraw()


        bpy.ops.object.mode_set(mode='OBJECT')

        return {'FINISHED'}
