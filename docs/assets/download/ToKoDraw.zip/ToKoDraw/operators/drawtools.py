import bpy
import gpu
from gpu_extras.batch import batch_for_shader




class td_OT_lasso_select(bpy.types.Operator):
    bl_idname = "td.lasso_select"
    bl_label = "Lasso Select"
    bl_description = "Dessine un lasso dans le viewport"

    _handle = None
    points = None
    drawing = False

    @classmethod
    def poll(cls, context):
        return context.area and context.area.type == 'VIEW_3D'
        



    @staticmethod
    def draw_callback_px(setd, context):
        if not setd.points or len(setd.points) < 2:
            return

        shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
        coords = setd.points

        batch = batch_for_shader(shader, 'LINE_STRIP', {"pos": coords})

        gpu.state.blend_set('ALPHA')
        shader.bind()
        shader.uniform_float("color", (1.0, 0.2, 0.2, 1.0))  
        batch.draw(shader)
        gpu.state.blend_set('NONE')




    def modal(setd, context, event):


        if event.type == 'MOUSEMOVE' and setd.drawing:
            setd.points.append((event.mouse_region_x, event.mouse_region_y))
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}


        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            setd.drawing = False
            setd.finish_lasso(context)
            return {'FINISHED'}


        if event.type in {'ESC'}:
            setd.cancel(context)
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}




    def invoke(setd, context, event):
        setd.points = []
        setd.drawing = True


        args = (setd, context)
        setd._handle = bpy.types.SpaceView3D.draw_handler_add(
            td_OT_lasso_select.draw_callback_px, args, 'WINDOW', 'POST_PIXEL'
        )

        context.window_manager.modal_handler_add(setd)
        return {'RUNNING_MODAL'}




    def finish_lasso(setd, context):
        print("Lasso terminé, points :", len(setd.points))


        setd.remove_handler(context)




    def cancel(setd, context):
        setd.remove_handler(context)




    def remove_handler(setd, context):
        if setd._handle is not None:
            bpy.types.SpaceView3D.draw_handler_remove(setd._handle, 'WINDOW')
            setd._handle = None
        context.area.tag_redraw()


