import bpy






def td_update_mode(setd, context):
    bpy.ops.object.mode_set(mode=setd.mode_selector)



def td_sync_mode(scene):
    obj = bpy.context.object
    if not obj:
        return

    current_mode = obj.mode
    general = scene.td_general

    if general and general.mode_selector != current_mode:
        general.mode_selector = current_mode





class tdGeneralProps(bpy.types.PropertyGroup):
    mode_selector: bpy.props.EnumProperty(
        name="Mode",
        items=[
            ('OBJECT', "Object", ""),
            ('EDIT', "Edit", ""),
            ('SCULPT', "Sculpt", ""),
            ('VERTEX_PAINT', "Vertex Paint", ""),
            ('WEIGHT_PAINT', "Weight Paint", ""),
            ('TEXTURE_PAINT', "Texture Paint", "")
        ],
        default='OBJECT',
        update=td_update_mode
    )









class TKDontextProps(bpy.types.PropertyGroup):
    clicked_layer_name: bpy.props.StringProperty()
    clicked_layer_uid: bpy.props.StringProperty()


class tdToneProps(bpy.types.PropertyGroup):
    brightness: bpy.props.FloatProperty(
        name="Brightness",
        default=0.0,
        min=-1.0,
        max=1.0
    )

    contrast: bpy.props.FloatProperty(
        name="Contrast",
        default=0.0,
        min=-1.0,
        max=1.0
    )

    gamma: bpy.props.FloatProperty(
        name="Gamma",
        default=1.0,
        min=0.1,
        max=5.0
    )







class td_OutlineProps(bpy.types.PropertyGroup):
    thickness: bpy.props.FloatProperty(default=0.01)
    hidden: bpy.props.BoolProperty(default=False)




class tdMergeProps(bpy.types.PropertyGroup):
    checked: bpy.props.BoolProperty(default=False)
    opacity: bpy.props.FloatProperty(default=1.0)
    blend_mode: bpy.props.EnumProperty(
        name="Blend Mode",
        items=[
            ('NORMAL', "Normal", ""),
            ('MULTIPLY', "Multiply", ""),
            ('SCREEN', "Screen", ""),
            ('OVERLAY', "Overlay", ""),
        ],
        default='NORMAL'
    )

def rebuild_merge_map(scene, layers):
    merge_map = scene.td_merge_map
    merge_map.clear()

    for layer in layers:
        uid = layer.get("td_uid")
        if not uid:
            continue

        item = merge_map.add()
        item.name = uid
        item.checked = False
