import bpy


from ..operators.set_opacity import update_opacity
from ..operators.mesh_outline import update_outline_thickness
from .props import (
    td_sync_mode,
    td_update_mode, 
    rebuild_merge_map
)


bpy.types.Scene.td_active_opacity = bpy.props.FloatProperty(
    min=0.0, max=1.0,
    update=update_opacity
)

bpy.types.Scene.td_outline_thickness = bpy.props.FloatProperty(
    min=0.001, max=1,
    default=0.01,
    update=update_outline_thickness
)


from .props import (

    tdGeneralProps, 
    td_update_mode,
    td_sync_mode, 

    td_OutlineProps,

    tdMergeProps,
    


    TKDontextProps,

    tdToneProps,
)








bpy.types.Scene.td_active_layer_index = bpy.props.IntProperty(
    name="Active Layer Index",
    default=0
)


bpy.types.Scene.td_active_layer = bpy.props.StringProperty(
    name="Active Layer",
    default=""
)


bpy.types.Scene.td_active_layer_uid = bpy.props.StringProperty(
    name="Active Layer UID",
    default=""
)


bpy.types.Scene.td_animate_layer = bpy.props.BoolProperty(
    name="Animate Layer",
    default=False
)



bpy.types.Scene.td_show_fx_tools = bpy.props.BoolProperty(
    name="Show FX Tools",
    default=False
)
bpy.types.Scene.td_show_layers_section = bpy.props.BoolProperty(
    name="Show Layers Section",
    default=True
)
bpy.types.Scene.td_show_opacity_section = bpy.props.BoolProperty(
    name="Show Opacity Section",
    default=True
)
bpy.types.Scene.td_show_render_section = bpy.props.BoolProperty(
    name="Show Render Section",
    default=False
)
bpy.types.Scene.td_show_normalmap_panel = bpy.props.BoolProperty(
    name="Show Normal Map Panel",
    default=False
)
bpy.types.Scene.td_show_normalmap_ui = bpy.props.BoolProperty(
    name="Show Normal Map UI",
    default=False
)
bpy.types.Scene.td_normalmap_open = bpy.props.BoolProperty(
    name="Normal Map Open",
    default=False
)
bpy.types.Scene.td_show_utils_section = bpy.props.BoolProperty(
    name="Show Utilities Section",
    default=False
)




bpy.types.Object.td_show_outline_settings = bpy.props.BoolProperty(
    name="Outline Settings",
    default=False
)
bpy.types.Scene.td_outline_hidden = bpy.props.BoolProperty(
    name="Hide Outline",
    default=False
)





bpy.types.Object.td_show_lineart_settings = bpy.props.BoolProperty(
    name="Show LineArt Settings",
    default=False
)
bpy.types.Object.td_lineart_setup = bpy.props.BoolProperty(
    name="LineArt Setup",
    default=False
)
bpy.types.Scene.td_lineart_mesh_source = bpy.props.StringProperty(
    name="LineArt Base Mesh",
    default=""
)
bpy.types.Scene.td_lineart_camview = bpy.props.BoolProperty(
    name="LineArt CamView Active",
    default=False
)


bpy.types.Scene.td_camview = bpy.props.BoolProperty(
    name="CamView Active",
    default=False
)


bpy.types.Scene.td_obj_transform_panel = bpy.props.BoolProperty(
    name="Show Obj Transform Panel",
    default=False
)







props_classes = (

    tdGeneralProps,


    td_OutlineProps,

    tdMergeProps,
    


    TKDontextProps,

    tdToneProps,
    
)



