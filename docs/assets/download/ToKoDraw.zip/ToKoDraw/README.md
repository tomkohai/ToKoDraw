

All rights reserved.  
© 2026 – To Kohai / ToKoDraw




ToKoDraw Canvas is an advanced multi‑material layer management system for Blender, designed for compositing, painting, 2D FX and stylized artistic workflows.

It provides a non‑destructive layer stack that can be reordered, merged, and fully synchronized with the Shader Editor.

Image Texture‑Based Workflow:

ToKoDraw is built on Blender’s Image Texture system, ensuring full compatibility with Cycles, Eevee, and all custom shaders.

Painting occurs before shading, making the workflow stable and predictable.

---





- Non‑destructive layer stack

- Add, remove, reorder, merge, and clean layers

- Per‑layer opacity and Hard Alpha control

- Per‑layer rendering mode (Emission / BSDF)

- Automatic material creation and removal

- Fully synchronized and stable Layer ↔ NBAdd pipeline



- Emission mode for NPR, cel‑shading, and stylized rendering

- BSDF mode for stylized painting with depth

- Render Switch for instant toggling

- Automatic Normal Map injection when painting in BSDF

- Dedicated palette for stylized normal painting



- Paint directly from the camera view

- Dedicated transform panel to orient the object while keeping Line Art aligned

- Ideal for stylized, anime, comic, NPR workflows



- Automatic add/remove of Line Art or Outline on the mesh

Perfect for stylized rendering, cel‑shading, anime, comics


ToKoDraw includes a complete 2D canvas, similar to a painting software:

- Create a 2D canvas (horizontal, vertical, custom)

- Paint directly on a flat surface

- Canvas can be hidden in Emission mode (PNG rendering)

- Ideal for backgrounds, FX, masks, stylized textures


ToKoDraw is actively developed. Planned features include:

- Vector painting tools (line, rectangle, ellipse, fill, lasso, pixel move)

- Advanced stylized filters

- 2D frame‑by‑frame animation pipeline (Krita‑like)

- Texture animation tools for Line Art and stylized FX

- New blend modes and painting tools



1. Download the add‑on ZIP file  
2. Blender → **Edit → Preferences → Add‑ons**  
3. Click **Install…**  
4. Select the ZIP  
5. Enable **ToKoDraw**

---


- **Create Mat or Canvas**: automatically creates the material and assigns it to the 3D object.
- **Remove Mat**: removes the material and all its content (node groups, layers, images…).
- **Mode**: changes Blender’s mode directly from the panel.
- **Add Layer**: adds a layer anywhere in the stack (also allows adding a normal map layer and automatically enables BSDF normal map mode).
- **Remove Layer**: removes the selected layer  
- **Reorder Layer**: moves a layer within the stack  
- **Merge Layers**: merges the layers checked in the Merge Map  
- **Radio Button**: selects the active layer in the stack.
- **Opacity Slider**: adjusts the opacity of the selected layer.
- **Hard Alpha Slider**: softens or hardens the alpha of the selected layer.
- **Settings (arrow)**: available on the active layer — manages the source image (layer images) and UV transformations.
- **Backface Culling**: disables painting on internal faces.
- **Render Switch**: automatically toggles between Emission and BSDF shaders.
- **Outline & Settings**: adds an outline mesh linked to the 3D object and provides access to its parameters.
- **Line Art & Settings**: adds a Grease Pencil Line Art and provides access to its parameters.
- **Set Camera View**: enables camera‑view painting mode and the object transform panel (editable in Texture Paint).
- **Set Object Transform Panel**: enables or disables the object transform panel independently of camera view.
- **Frame Selected**: frames the camera on the selected object.

---



- Blender **4.x**  
- Cycles / Eevee  
- Custom Node Groups  
- Complex materials  
- Multi‑material setups

---



**Version: 1.0.0 — First stable release**

See the **CHANGELOG.md** file.

---



ToKoDraw is distributed under a **free proprietary license with source access** (*Free Proprietary, Source‑Available License*).

You may:
- use the extension for free in personal and professional projects;
- modify the source code strictly for your private use.

You may not:
- redistribute the extension or its source code, whether modified or not;
- publish or share a modified version;
- create derivative works, forks, or extensions based on this code;
- reuse any part of the code in another project.

See the `LICENSE` file for more details.

---



For any question, suggestion, or bug:  

- GitHub Issues: https://github.com/tomkohai/ToKoDraw

- Website: https://tomkohai.github.io/ToKoDraw/

- Social networks:  
  https://www.instagram.com/tomkohai/  
  https://www.tiktok.com/@tom.kohai  
  https://www.linkedin.com/in/thomas-chauveau-eg/

- Direct contact: tokodraw@gmail.com

- Developer contact: tomkohai@gmail.com 

- Downloads: gumroad and itch.io (to be added)

- Community: https://discord.gg/YHYVpDFUY5

- Support: to be added










All rights reserved.  
© 2026 – To Kohai / ToKoDraw




ToKoDraw est un système de gestion de calques (multi matériaux) avancé pour Blender, conçu pour le compositing, la peinture, le FX 2D et les workflows artistiques stilysés  

Il apporte une pile de layers non destructifs, réordonnables, fusionnables et entièrement synchronisés avec le Shader Editor.

Workflow basé sur Image Texture :

ToKoDraw repose sur le système d’Image Texture de Blender, garantissant une compatibilité totale avec Cycles, Eevee et tous les shaders personnalisés.

La peinture se fait avant le shading, ce qui rend le workflow stable et prévisible.

---





- Pile de layers non destructifs

- Ajout, suppression, réorganisation, fusion et nettoyage des layers

- Contrôle par‑layer de l’opacité et du Hard Alpha

- Changement de mode de rendu par layer (Emission / BSDF)

- Création et suppression automatique du matériau

- Pipeline Layer ↔ NBAdd entièrement synchronisé et stable



- Mode Emission pour le NPR, le cel‑shading et les rendus stylisés

- Mode BSDF pour la peinture stylisée avec profondeur

- Render Switch pour basculer instantanément entre les deux

- Injection automatique de Normal Maps lors de la peinture en BSDF

- Palette dédiée pour la peinture de normales stylisées



- Peinture directement depuis la vue caméra

- Panel de transformation dédié pour orienter l’objet tout en gardant le Line Art aligné

- Idéal pour les workflows stylisés, anime, comic, NPR



- Ajout/suppression automatique de Line Art ou Outline sur le mesh

Parfait pour les rendus stylisés, cel‑shading, anime, BD


ToKoDraw inclut un canvas 2D complet, comme dans un logiciel de peinture :

- Création d’une toile 2D (horizontal, vertical, custom)

- Peinture directe sur une surface plane

- Canvas masquable en mode Emission (rendu png) 

- Idéal pour les backgrounds, FX, masques, textures stylisées


ToKoDraw est activement développé. Les fonctionnalités prévues incluent :

- Outils de peinture vectorisés (ligne, rectangle, ellipse, remplissage, lasso, déplacement de pixels)

- Filtres stylisés avancés

- Pipeline d’animation 2D image‑par‑image (type Krita)

- Animation de textures pour Line Art et FX stylisés

- Nouveaux modes de fusion et outils de peinture



1. Télécharger le fichier ZIP de l’addon  
2. Blender → **Edit → Preferences → Add-ons**  
3. Cliquer **Install…**  
4. Sélectionner le ZIP  
5. Activer **ToKoDraw**

---


- **Create Mat or canva** : crée automatiquement le matériau et l’assigne à l’objet 3D. 
- **Remove mat** : supprime le matériau et tout son contenu (node groups, layers, images…).
- **Mode** : change le mode Blender directement depuis le panel.
- **Add Layer** : ajoute un calque n’importe où dans la pile (permet aussi d’ajouter un calque de normal map et active automatiquement le mode BSDF normal map).
- **Remove Layer** : supprime le calque sélectionné  
- **Reorder Layer** : déplace un calque dans la pile  
- **Merge Layers** : fusionne les layers cochés dans le Merge Map  
- **Radio button** : sélectionne le layer actif dans la pile.
- **Slider d'opécité** : ajuste l’opacité du layer sélectionné.
- **Slider hard alpha** : adoucit ou durcit l’alpha du layer sélectionné.
- **settings (flèche) ** : accessible sur le layer actif — gestion de l’image source (images des layers) et gestion des transformations UV.
- **Backface culling** : désactive la peinture sur les faces internes.
- **Render switch** : bascule automatiquement entre le shader Emission ou BSDF.
- **Outline & settings** : ajoute un mesh d’outline lié à l’objet 3D et donne accès aux paramètres.
- **Line art & settings** : ajoute un Grease Pencil Line Art et donne accès aux paramètres.
- **Set camera view** : active le mode peinture en vue caméra et le panel de transformation d’objet (éditable en Texture Paint).
- **Set objet transform panel** : active ou désactive le panel de transformation d’objet indépendamment du mode caméra.
- **Frame selected** : oriente la caméra vers l’objet sélectionné.
---



- Blender **4.x**  
- Cycles / Eevee  
- Node Groups personnalisés  
- Matériaux complexes
- Multi matériaux 

---



**Version : 1.0.0 — Première version stable**

Voir le fichier **CHANGELOG.md** 

---



ToKoDraw est distribué sous une **licence propriétaire gratuite avec accès au code source** (*Free Proprietary, Source-Available License*).

Vous pouvez :
- utiliser l'extension gratuitement dans le cadre de projets personnels et professionnels ;
- modifier le code source strictement pour votre usage privé.

Vous ne pouvez pas :
- redistribuer l'extension ou son code source, qu'ils soient modifiés ou non ;
- publier ou partager une version modifiée ;
- créer des œuvres dérivées, des *forks* ou des extensions basés sur ce code ;
- réutiliser une partie du code dans un autre projet.

Consultez le fichier `LICENSE` pour plus de détails.

---



Pour toute question, suggestion ou bug :  

- GitHub Issues : https://github.com/tomkohai/ToKoDraw-Canvas 

- Site :    https://tomkohai.github.io/ToKoDraw-Canvas/

- Réseaxu : https://www.instagram.com/tomkohai/
            https://www.tiktok.com/@tom.kohai
            https://www.linkedin.com/in/thomas-chauveau-eg/


- Contact direct : ToKoDraw@gmail.com

- Contact developpeur : tomkohai@gmail.com 

- Téléchargements : gumroad et itch.io (a ajouter) 

- Communauté : https://discord.gg/YHYVpDFUY5

- Soutient : à ajouter 