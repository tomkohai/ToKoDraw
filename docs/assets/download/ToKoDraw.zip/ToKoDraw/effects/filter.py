import bpy
import numpy as np





def apply_brightness_contrast(arr, brightness=0.0, contrast=0.0):
    """
    arr : numpy array (H*W, 4) float32 RGBA 0-1
    brightness : -1.0 → +1.0
    contrast   : -1.0 → +1.0
    """
    rgb = arr[:, :3]


    if brightness != 0.0:
        rgb = np.clip(rgb + brightness, 0.0, 1.0)



    if contrast != 0.0:
        rgb = np.power(rgb, 1.0 - contrast)



    np.clip(rgb, 0.0, 1.0, out=rgb)

    arr[:, :3] = rgb
    return arr






def apply_gamma(arr, gamma=1.0):
    """
    gamma : >0.0
    """
    if gamma == 1.0:
        return arr

    rgb = arr[:, :3]

    gamma = max(gamma, 0.0001)

    rgb = np.power(rgb, gamma)
    np.clip(rgb, 0.0, 1.0, out=rgb)

    arr[:, :3] = rgb
    return arr






def apply_luminance_gain(arr, gain=1.0):
    """
    gain : multiplicateur direct
    """
    if gain == 1.0:
        return arr

    rgb = arr[:, :3]
    rgb *= gain
    np.clip(rgb, 0.0, 1.0, out=rgb)

    arr[:, :3] = rgb
    return arr




class td_OT_apply_tone_settings(bpy.types.Operator):
    bl_idname = "td.apply_tone_settings"
    bl_label = "Apply Tone Settings"

    def execute(setd, context):
        scene = context.scene
        layer = getattr(context, "td_layer", None)

        if not layer:
            setd.report({'ERROR'}, "No layer selected")
            return {'CANCELLED'}


        brightness = scene.td_brightness
        contrast   = scene.td_contrast
        gamma      = scene.td_gamma


        img = bpy.data.images.get(layer.image_name)
        if not img:
            setd.report({'ERROR'}, "Layer has no image")
            return {'CANCELLED'}


        arr = np.array(img.pixels[:], dtype=np.float32)
        arr = arr.reshape((img.size[1] * img.size[0], 4))


        arr = apply_brightness_contrast(arr, brightness, contrast)
        arr = apply_gamma(arr, gamma)


        img.pixels[:] = arr.flatten()

        setd.report({'INFO'}, "Tone applied")
        return {'FINISHED'}
