import bpy 

from .prefs import ToKoDrawPreferences

prefs_classes = (
    ToKoDrawPreferences,
)