import bpy 


class ToKoDrawPreferences(bpy.types.AddonPreferences):
    bl_idname = "ToKoDraw"

    show_lock_alpha_warning: bpy.props.BoolProperty(
        name="Show Lock Alpha Warning",
        default=True
    )

    show_lock_layer_warning: bpy.props.BoolProperty(
        name="Show Lock Layer Warning",
        default=True
    )

    show_merge_layers_warning: bpy.props.BoolProperty(
        name="Show Merge Layers Popup",
        default=True
    )

    def draw(setd, context):
        layout = setd.layout
        layout.label(text="ToKoDraw Preferences")
        layout.prop(setd, "show_lock_alpha_warning")
        layout.prop(setd, "show_lock_layer_warning")
        layout.prop(setd, "show_merge_layers_warning")