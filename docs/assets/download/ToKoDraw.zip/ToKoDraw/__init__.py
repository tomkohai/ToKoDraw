bl_info = {
    "name": "ToKoDraw",
    "wiki_url": "https://tomkohai.github.io/ToKoDraw/",
    "author": "Thomas Chauveau - ToKohai",
    "version": (1, 0, 0),
    "blender": (4, 5, 0),
    "location": "View3D > N Panel > ToKoDraw",
    "description": "Texture Paint Layer System (Krita-like) for Blender",
    "category": "Paint",
    "licence" : "Free Proprietary License (Source-Available)", 
}

import bpy


from .core import *


from .operators import *
from .operators import operator_classes


from .properties import *
from .properties import props_classes


from .preferencies import *
from .preferencies import prefs_classes


from .buffers import *
from .buffers import buffer_classes


from .ui import *
from .ui import ui_classes


from .effects import *
from .effects import effects_classes





def register():






    for cls in operator_classes:
        bpy.utils.register_class(cls)


    for cls in ui_classes:
        bpy.utils.register_class(cls)


    for cls in props_classes:
        bpy.utils.register_class(cls)


    for cls in prefs_classes:
        bpy.utils.register_class(cls)


    for cls in buffer_classes:
        bpy.utils.register_class(cls)







    bpy.types.Scene.td_general = bpy.props.PointerProperty(type=tdGeneralProps)


    bpy.types.Scene.td_layer_buffers = bpy.props.PointerProperty(type=td_LayerBufferStore)


    bpy.types.UI_MT_button_context_menu.append(draw_layer_context_menu)


    bpy.types.Object.name_old = bpy.props.StringProperty()


    bpy.types.Scene.td_merge_map = bpy.props.CollectionProperty(type=tdMergeProps)


    bpy.types.Scene.td_context = bpy.props.PointerProperty(type=TKDontextProps)
    bpy.types.Scene.td_tone = bpy.props.PointerProperty(type=tdToneProps)


    bpy.types.Scene.td_outline = bpy.props.PointerProperty(type=td_OutlineProps)


    bpy.app.handlers.depsgraph_update_post.append(td_sync_mode)


    bpy.app.handlers.depsgraph_update_post.append(td_sync_lineart_name)
    bpy.app.handlers.depsgraph_update_post.append(td_sync_outline_name)


    if td_lock_alpha_handler not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(td_lock_alpha_handler)


    if fix_lineart_material not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(fix_lineart_material)






def unregister():




    bpy.types.UI_MT_button_context_menu.remove(draw_layer_context_menu)




    handlers = bpy.app.handlers.depsgraph_update_post

    if td_sync_mode in handlers:
        handlers.remove(td_sync_mode)

    if td_sync_lineart_name in handlers:
        handlers.remove(td_sync_lineart_name)

    if td_sync_outline_name in handlers:
        handlers.remove(td_sync_outline_name)

    if td_lock_alpha_handler in handlers:
        handlers.remove(td_lock_alpha_handler)

    if fix_lineart_material in handlers:
        handlers.remove(fix_lineart_material)





    del bpy.types.Scene.td_general
    del bpy.types.Scene.td_layer_buffers
    del bpy.types.Scene.td_outline
    del bpy.types.Scene.td_outline_hidden
    del bpy.types.Scene.td_outline_thickness
    del bpy.types.Scene.td_lineart_mesh_source
    del bpy.types.Scene.td_lineart_camview
    del bpy.types.Scene.td_active_opacity
    del bpy.types.Scene.td_active_layer_index
    del bpy.types.Scene.td_active_layer
    del bpy.types.Scene.td_active_layer_uid
    del bpy.types.Scene.td_context
    del bpy.types.Scene.td_tone
    del bpy.types.Scene.td_animate_layer
    del bpy.types.Scene.td_show_fx_tools
    del bpy.types.Scene.td_show_render_section
    del bpy.types.Scene.td_show_normalmap_panel
    del bpy.types.Scene.td_show_normalmap_ui
    del bpy.types.Scene.td_normalmap_open
    del bpy.types.Scene.td_show_utils_section
    del bpy.types.Scene.td_merge_map




    del bpy.types.Object.name_old
    del bpy.types.Object.td_show_outline_settings
    del bpy.types.Object.td_show_lineart_settings
    del bpy.types.Object.td_lineart_setup






    for cls in reversed(operator_classes):
        try: bpy.utils.unregister_class(cls)
        except RuntimeError: pass


    for cls in reversed(prefs_classes):
        try: bpy.utils.unregister_class(cls)
        except RuntimeError: pass


    for cls in reversed(props_classes):
        try: bpy.utils.unregister_class(cls)
        except RuntimeError: pass


    for cls in reversed(buffer_classes):
        try: bpy.utils.unregister_class(cls)
        except RuntimeError: pass


    for cls in reversed(ui_classes):
        try: bpy.utils.unregister_class(cls)
        except RuntimeError: pass
