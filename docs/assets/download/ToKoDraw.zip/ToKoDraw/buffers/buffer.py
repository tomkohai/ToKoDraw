import bpy
from bpy.types import PropertyGroup

class td_LayerBufferStore(PropertyGroup):
    pass


